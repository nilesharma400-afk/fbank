import numpy as np
import pandas as pd
import random
from datetime import datetime, timedelta

def generate_large_dataset(n_samples=12000):
    """
    Generate a large dataset of 10,000-15,000 loan applications
    """
    np.random.seed(42)
    random.seed(42)
    
    print(f"Generating {n_samples} loan application records...")
    
    # Indian names for realistic data
    first_names = [
        'Rajesh', 'Priya', 'Amit', 'Sunita', 'Vikram', 'Kavita', 'Ramesh', 'Anita', 'Suresh', 'Meera',
        'Ajay', 'Pooja', 'Ravi', 'Neha', 'Manoj', 'Sushma', 'Rajesh', 'Anjali', 'Vikash', 'Poonam',
        'Arun', 'Deepa', 'Kiran', 'Lakshmi', 'Naveen', 'Rekha', 'Sandeep', 'Usha', 'Vinod', 'Geeta',
        'Harish', 'Indira', 'Jagdish', 'Kamala', 'Lalit', 'Madhu', 'Niranjan', 'Omprakash', 'Prabha', 'Rajni',
        'Suman', 'Tara', 'Umesh', 'Vandana', 'Yogesh', 'Zarina', 'Ashok', 'Bharti', 'Chandra', 'Devendra',
        'Ekta', 'Farooq', 'Ganga', 'Hari', 'Ishwar', 'Jyoti', 'Kailash', 'Lata', 'Mahesh', 'Nirmala',
        'Omkar', 'Pushpa', 'Rohit', 'Shanti', 'Tulsi', 'Uma', 'Vijay', 'Wahida', 'Xavier', 'Yashoda'
    ]
    
    last_names = [
        'Kumar', 'Sharma', 'Patel', 'Devi', 'Singh', 'Joshi', 'Yadav', 'Gupta', 'Kumar', 'Singh',
        'Verma', 'Agarwal', 'Tiwari', 'Sharma', 'Kumar', 'Devi', 'Gupta', 'Singh', 'Kumar', 'Sharma',
        'Reddy', 'Nair', 'Iyer', 'Menon', 'Pillai', 'Nair', 'Krishnan', 'Raman', 'Subramanian', 'Venkatesh',
        'Choudhary', 'Jain', 'Agarwal', 'Goel', 'Malhotra', 'Khanna', 'Bansal', 'Goyal', 'Mittal', 'Aggarwal',
        'Bhatt', 'Pandey', 'Mishra', 'Saxena', 'Trivedi', 'Dwivedi', 'Shukla', 'Pandit', 'Upadhyay', 'Dubey'
    ]
    
    # Generate names
    names = [f"{random.choice(first_names)} {random.choice(last_names)}" for _ in range(n_samples)]
    
    # Generate ages (22-65)
    ages = np.random.normal(35, 10, n_samples)
    ages = np.clip(ages, 22, 65).astype(int)
    
    # Generate monthly income (15,000 - 200,000)
    monthly_incomes = np.random.lognormal(10, 0.5, n_samples)
    monthly_incomes = np.clip(monthly_incomes, 15000, 200000).astype(int)
    
    # Generate monthly debt (5,000 - 80,000)
    monthly_debts = np.random.lognormal(9, 0.4, n_samples)
    monthly_debts = np.clip(monthly_debts, 5000, 80000).astype(int)
    
    # Generate CIBIL scores (300-900)
    cibil_scores = np.random.normal(700, 100, n_samples)
    cibil_scores = np.clip(cibil_scores, 300, 900).astype(int)
    
    # Generate loan amounts (50,000 - 5,000,000)
    loan_amounts = np.random.lognormal(12, 0.6, n_samples)
    loan_amounts = np.clip(loan_amounts, 50000, 5000000).astype(int)
    
    # Generate property values (100,000 - 10,000,000)
    property_values = np.random.lognormal(13, 0.5, n_samples)
    property_values = np.clip(property_values, 100000, 10000000).astype(int)
    
    # Generate employment years (0-40)
    employment_years = np.random.exponential(6, n_samples)
    employment_years = np.clip(employment_years, 0, 40).astype(int)
    
    # Employment types
    employment_types = np.random.choice(['salaried', 'self_employed', 'business'], n_samples, p=[0.6, 0.25, 0.15])
    
    # Education levels
    education_levels = np.random.choice(['high_school', 'diploma', 'graduate', 'post_graduate'], n_samples, p=[0.2, 0.3, 0.35, 0.15])
    
    # Marital status
    marital_statuses = np.random.choice(['single', 'married', 'divorced'], n_samples, p=[0.3, 0.65, 0.05])
    
    # Property types
    property_types = np.random.choice(['residential', 'commercial', 'agricultural'], n_samples, p=[0.7, 0.2, 0.1])
    
    # Create DataFrame
    data = {
        'name': names,
        'age': ages,
        'monthly_income': monthly_incomes,
        'monthly_debt': monthly_debts,
        'cibil_score': cibil_scores,
        'loan_amount': loan_amounts,
        'property_value': property_values,
        'employment_years': employment_years,
        'employment_type': employment_types,
        'education': education_levels,
        'marital_status': marital_statuses,
        'property_type': property_types
    }
    
    df = pd.DataFrame(data)
    
    # Create target variable based on realistic business rules
    # More sophisticated loan approval criteria
    df['loan_approved'] = (
        (df['cibil_score'] >= 650) &  # Good CIBIL score
        (df['monthly_income'] >= 25000) &  # Minimum income
        (df['monthly_debt'] / df['monthly_income'] <= 0.4) &  # Debt-to-income ratio
        (df['employment_years'] >= 2) &  # Minimum employment history
        (df['age'] >= 25) &  # Minimum age
        (df['age'] <= 60) &  # Maximum age
        (df['loan_amount'] <= df['property_value'] * 0.8) &  # Loan-to-value ratio
        (df['loan_amount'] <= df['monthly_income'] * 60)  # Income multiple
    ).astype(int)
    
    # Add some randomness to make it more realistic
    # 5% of applications get approved despite not meeting all criteria (special cases)
    special_cases = np.random.choice(n_samples, int(n_samples * 0.05), replace=False)
    df.loc[special_cases, 'loan_approved'] = 1
    
    # 3% of applications get rejected despite meeting criteria (other factors)
    rejection_cases = np.random.choice(n_samples, int(n_samples * 0.03), replace=False)
    df.loc[rejection_cases, 'loan_approved'] = 0
    
    print(f"Dataset generated successfully!")
    print(f"Total records: {len(df)}")
    print(f"Approved loans: {df['loan_approved'].sum()}")
    print(f"Rejected loans: {len(df) - df['loan_approved'].sum()}")
    print(f"Approval rate: {df['loan_approved'].mean():.2%}")
    
    return df

def save_large_dataset(df, filename='data/large_loan_dataset_cibil.csv'):
    """Save the large dataset to CSV file"""
    df.to_csv(filename, index=False)
    print(f"Dataset saved to {filename}")
    return filename

if __name__ == "__main__":
    # Generate dataset with 12,000 records
    dataset = generate_large_dataset(12000)
    
    # Save to file
    save_large_dataset(dataset)
    
    # Display sample statistics
    print("\nDataset Statistics:")
    print("=" * 50)
    print(f"Age range: {dataset['age'].min()} - {dataset['age'].max()}")
    print(f"Income range: ₹{dataset['monthly_income'].min():,} - ₹{dataset['monthly_income'].max():,}")
    print(f"CIBIL score range: {dataset['cibil_score'].min()} - {dataset['cibil_score'].max()}")
    print(f"Loan amount range: ₹{dataset['loan_amount'].min():,} - ₹{dataset['loan_amount'].max():,}")
    
    print("\nEmployment Type Distribution:")
    print(dataset['employment_type'].value_counts())
    
    print("\nEducation Distribution:")
    print(dataset['education'].value_counts())
    
    print("\nMarital Status Distribution:")
    print(dataset['marital_status'].value_counts())
    
    print("\nProperty Type Distribution:")
    print(dataset['property_type'].value_counts())
