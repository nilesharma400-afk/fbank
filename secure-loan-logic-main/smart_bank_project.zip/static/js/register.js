import { supabase } from './supabaseClient.js';

document.addEventListener('DOMContentLoaded', () => {
    const multiStepForm = document.getElementById('multiStepRegisterForm');
    if (!multiStepForm) return;

    const nextBtn = document.getElementById('nextBtn');
    const prevBtn = document.getElementById('prevBtn');
    const submitBtn = document.getElementById('submitBtn');
    const steps = Array.from(multiStepForm.querySelectorAll('.form-step'));
    const stepIndicators = Array.from(document.querySelectorAll('.step-indicator .step'));
    let currentStep = 1;
    const totalSteps = steps.length;

    function updateButtons() {
        prevBtn.style.display = currentStep > 1 ? 'inline-block' : 'none';
        nextBtn.style.display = currentStep < totalSteps ? 'inline-block' : 'none';
        submitBtn.style.display = currentStep === totalSteps ? 'inline-block' : 'none';
    }

    function updateStepIndicator() {
        stepIndicators.forEach((step, index) => {
            const stepNumber = index + 1;
            step.classList.remove('active', 'completed');
            if (stepNumber < currentStep) {
                step.classList.add('completed');
            } else if (stepNumber === currentStep) {
                step.classList.add('active');
            }
        });
    }

    function showStep(stepNumber) {
        steps.forEach(step => {
            step.classList.toggle('active', parseInt(step.dataset.step) === stepNumber);
        });
        currentStep = stepNumber;
        updateButtons();
        updateStepIndicator();
    }

    function validateStep(stepNumber) {
        const currentStepElement = steps[stepNumber - 1];
        if (!currentStepElement) return false;

        const currentStepFields = currentStepElement.querySelectorAll('[required]');
        let isValid = true;
        currentStepFields.forEach(field => {
            field.classList.remove('is-invalid');
            if (!field.checkValidity()) {
                field.classList.add('is-invalid');
                isValid = false;
            }
        });

        if (stepNumber === 1) {
            const password = document.getElementById('regPassword');
            const confirmPassword = document.getElementById('confirmPassword');
            const passwordStrengthValid = checkPasswordStrength(password.value, false);

            confirmPassword.classList.remove('is-invalid');
            if (password.value !== confirmPassword.value) {
                confirmPassword.classList.add('is-invalid');
                isValid = false;
            }
            if (!passwordStrengthValid) {
                password.classList.add('is-invalid');
                isValid = false;
            }
        }
        return isValid;
    }

    nextBtn.addEventListener('click', () => {
        if (validateStep(currentStep) && currentStep < totalSteps) {
            showStep(currentStep + 1);
        }
    });

    prevBtn.addEventListener('click', () => {
        if (currentStep > 1) {
            showStep(currentStep - 1);
        }
    });

    multiStepForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        if (!validateStep(currentStep)) {
            alert('Please fill out all required fields correctly.');
            return;
        }
        
        submitBtn.disabled = true;
        submitBtn.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Registering...`;

        const formData = new FormData(multiStepForm);
        const email = formData.get('regEmail');
        const password = formData.get('regPassword');
        
        const profileData = {
            full_name: formData.get('regFullName'),
            date_of_birth: formData.get('regDob'),
            gender: formData.get('regGender'),
            pan_number: formData.get('regPan'),
            aadhaar_number: formData.get('regAadhaar'),
            phone: formData.get('regPhone'),
            address: formData.get('regAddress'),
            city: formData.get('regCity'),
            state: formData.get('regState'),
            pincode: formData.get('regPincode')
        };

        const { data, error } = await supabase.auth.signUp({
            email: email,
            password: password,
            options: {
                data: profileData // This data is passed to the trigger to create the profile
            }
        });

        if (error) {
            alert(`Registration failed: ${error.message}`);
            submitBtn.disabled = false;
            submitBtn.innerHTML = `<i class="fas fa-check-circle me-2"></i>Create Account`;
        } else if (data.user) {
            // Redirect to a page informing the user to check their email
             window.location.href = '/index.html?registered=true';
        }
    });

    const passwordInput = document.getElementById('regPassword');
    const strengthItems = {
        length: document.getElementById('strength-length'),
        uppercase: document.getElementById('strength-uppercase'),
        lowercase: document.getElementById('strength-lowercase'),
        number: document.getElementById('strength-number'),
        special: document.getElementById('strength-special'),
    };

    function checkPasswordStrength(password, updateUI = true) {
        const validations = {
            length: password.length >= 8,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            number: /[0-9]/.test(password),
            special: /[\W_]/.test(password),
        };

        if (updateUI) {
            for (const key in validations) {
                const item = strengthItems[key];
                if (item) {
                    item.classList.toggle('valid', validations[key]);
                }
            }
        }
        
        return Object.values(validations).every(Boolean);
    }

    if (passwordInput) {
        passwordInput.addEventListener('input', () => {
            checkPasswordStrength(passwordInput.value);
        });
    }

    showStep(1);
});
