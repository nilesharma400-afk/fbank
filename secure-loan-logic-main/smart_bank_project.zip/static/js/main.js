import { supabase } from './supabaseClient.js';

// --- Global State ---
let currentUser = null;

// --- Theme Management ---
const themeSwitcher = document.getElementById('theme-switcher');
const currentTheme = localStorage.getItem('theme');

if (currentTheme === 'dark') {
    document.body.classList.add('dark-mode');
    if(themeSwitcher) themeSwitcher.innerHTML = '<i class="fas fa-sun"></i>';
}

if(themeSwitcher) {
    themeSwitcher.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        let theme = 'light';
        if (document.body.classList.contains('dark-mode')) {
            theme = 'dark';
            themeSwitcher.innerHTML = '<i class="fas fa-sun"></i>';
        } else {
            themeSwitcher.innerHTML = '<i class="fas fa-moon"></i>';
        }
        localStorage.setItem('theme', theme);
    });
}

// --- App Initialization ---
document.addEventListener('DOMContentLoaded', () => {
    initializePasswordToggles();
    initializeFormHandlers();
    handleUrlParams();
    
    // Centralized Auth State Handling
    supabase.auth.onAuthStateChange((_event, session) => {
        currentUser = session?.user || null;
        updateNavAndCtas(session);

        // If on dashboard, initialize dashboard-specific functions
        if (document.body.classList.contains('dashboard-page')) {
            if (currentUser) {
                initializeDashboard();
            } else {
                // If session ends, redirect to login
                window.location.href = '/index.html';
            }
        }
    });
});

function handleUrlParams() {
    const params = new URLSearchParams(window.location.search);
    if (params.get('registered') === 'true') {
        showAlert('success', 'Registration successful! Please check your email to verify your account before logging in.');
        const loginModalEl = document.getElementById('loginModal');
        if (loginModalEl) {
            const loginModal = new bootstrap.Modal(loginModalEl);
            loginModal.show();
        }
        window.history.replaceState({}, document.title, "/index.html");
    }
    if (window.location.hash === '#login') {
        const loginModalEl = document.getElementById('loginModal');
        if (loginModalEl) {
            const loginModal = new bootstrap.Modal(loginModalEl);
            loginModal.show();
        }
        window.location.hash = '';
    }
}

// --- Authentication and UI Updates ---
function updateNavAndCtas(session) {
    const isLoggedIn = !!session;
    const navAuthLinks = document.getElementById('nav-auth-links');
    const heroCtaButtons = document.getElementById('hero-cta-buttons');
    const footerCtaSection = document.getElementById('footer-cta-section');

    if (navAuthLinks) {
        if (isLoggedIn) {
            navAuthLinks.innerHTML = `
                <a class="nav-link" href="/dashboard.html">
                    <i class="fas fa-tachometer-alt me-1"></i>Dashboard
                </a>
                <a class="nav-link" href="#" id="logout-link">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            `;
            document.getElementById('logout-link').addEventListener('click', handleLogout);
        } else {
            navAuthLinks.innerHTML = `
                <a class="nav-link" href="#" data-bs-toggle="modal" data-bs-target="#loginModal">
                    <i class="fas fa-sign-in-alt me-1"></i>Login
                </a>
                <a class="nav-link fw-bold" href="/register.html">
                    Register
                </a>
            `;
        }
    }

    if (heroCtaButtons) {
        if (isLoggedIn) {
            heroCtaButtons.innerHTML = `<a href="/dashboard.html" class="btn btn-primary btn-lg"><i class="fas fa-tachometer-alt me-2"></i> Go to Dashboard</a>`;
        } else {
            heroCtaButtons.innerHTML = `
                <a href="/register.html" class="btn btn-primary btn-lg"><i class="fas fa-rocket me-2"></i> Get Started</a>
                <button class="btn btn-outline-light btn-lg" onclick="window.scrollToFeatures()"><i class="fas fa-info-circle me-2"></i> Learn More</button>
            `;
        }
    }
    
    if (footerCtaSection) {
        if (isLoggedIn) {
            footerCtaSection.innerHTML = `
                <h2 class="display-6 fw-bold mb-3">Welcome Back!</h2>
                <p class="lead mb-4">Ready to continue your loan application journey?</p>
                <a href="/dashboard.html" class="btn btn-primary btn-lg"><i class="fas fa-tachometer-alt me-2"></i> Go to Dashboard</a>
            `;
        } else {
            footerCtaSection.innerHTML = `
                <h2 class="display-6 fw-bold mb-3">Ready to Get Started?</h2>
                <p class="lead mb-4">Join us by creating a secure account to experience our advanced loan approval system.</p>
                <a href="/register.html" class="btn btn-primary btn-lg"><i class="fas fa-user-plus me-2"></i> Create Your Account</a>
            `;
        }
    }
}

async function handleLogout(e) {
    e.preventDefault();
    const { error } = await supabase.auth.signOut();
    if (error) {
        showAlert('danger', `Logout failed: ${error.message}`);
    } else {
        showAlert('success', 'You have been logged out.');
        setTimeout(() => {
            window.location.href = '/index.html';
        }, 1000);
    }
}

// --- Form & Event Handlers ---
function initializeFormHandlers() {
    const loginForm = document.getElementById('loginForm');
    if (loginForm) loginForm.addEventListener('submit', handleLogin);
    
    const loanForm = document.getElementById('loanApplicationForm');
    if (loanForm) loanForm.addEventListener('submit', handleLoanApplication);
    
    const changePasswordForm = document.getElementById('changePasswordForm');
    if (changePasswordForm) changePasswordForm.addEventListener('submit', handleChangePassword);

    const profileForm = document.getElementById('profileForm');
    if (profileForm) profileForm.addEventListener('submit', handleProfileUpdate);
}

// --- Authentication API Handlers ---
async function handleLogin(e) {
    e.preventDefault();
    const form = e.target;
    const email = form.querySelector('#username').value;
    const password = form.querySelector('#password').value;
    const submitButton = form.querySelector('button[type="submit"]');
    submitButton.disabled = true;
    submitButton.innerHTML = `<span class="spinner-border spinner-border-sm"></span> Logging in...`;

    const { error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
        showAlert('danger', error.message);
        submitButton.disabled = false;
        submitButton.textContent = 'Login';
    } else {
        showAlert('success', 'Login successful! Redirecting...');
        window.location.href = '/dashboard.html';
    }
}

// --- Dashboard Functions ---
function initializeDashboard() {
    fetchUserProfile();
    fetchApplicationHistory();
    window.showSection('loan-application'); // Set default view
}

async function fetchUserProfile() {
    if (!currentUser) return;
    const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', currentUser.id)
        .single();

    if (error) {
        console.error('Error fetching profile:', error);
    } else if (data) {
        document.getElementById('profileFullName').value = data.full_name || '';
        document.getElementById('profileDob').value = data.date_of_birth || '';
        document.getElementById('profilePan').value = data.pan_number || '';
        document.getElementById('profileAadhaar').value = data.aadhaar_number || '';
        document.getElementById('profilePhone').value = data.phone || '';
        document.getElementById('profileAddress').value = data.address || '';
        document.getElementById('profileCity').value = data.city || '';
        document.getElementById('profileState').value = data.state || '';
        document.getElementById('profilePincode').value = data.pincode || '';
        document.getElementById('profileEmail').value = currentUser.email;
        
        // Also populate the name in the loan application form
        const loanAppNameField = document.getElementById('name');
        if (loanAppNameField) {
            loanAppNameField.value = data.full_name || '';
        }

        // Update welcome message
        const welcomeHeader = document.querySelector('.sidebar .card-header h5');
        if(welcomeHeader) welcomeHeader.innerHTML = `<i class="fas fa-user-circle me-2"></i> Welcome, ${data.full_name.split(' ')[0]}`;
    }
}

async function handleProfileUpdate(e) {
    e.preventDefault();
    if (!currentUser) return;
    
    const formData = new FormData(e.target);
    const updates = {
        full_name: formData.get('profileFullName'),
        date_of_birth: formData.get('profileDob'),
        pan_number: formData.get('profilePan'),
        aadhaar_number: formData.get('profileAadhaar'),
        phone: formData.get('profilePhone'),
        address: formData.get('profileAddress'),
        city: formData.get('profileCity'),
        state: formData.get('profileState'),
        pincode: formData.get('profilePincode'),
    };

    const { error } = await supabase.from('profiles').update(updates).eq('id', currentUser.id);
    if (error) {
        showAlert('danger', `Failed to update profile: ${error.message}`);
    } else {
        showAlert('success', 'Profile updated successfully!');
        fetchUserProfile(); // Refresh welcome message
    }
}

async function handleLoanApplication(e) {
    e.preventDefault();
    if (!validateForm('loanApplicationForm') || !currentUser) {
        showAlert('danger', 'Please fill out all required fields.');
        return;
    }
    
    const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
    loadingModal.show();
    
    const formData = new FormData(e.target);
    const applicationData = { ...Object.fromEntries(formData.entries()), user_id: currentUser.id };
    
    // FIX: The 'name' column does not exist in 'loan_applications'.
    // The user's name is linked via their profile.
    delete applicationData.name;

    const { data, error } = await supabase.from('loan_applications').insert([applicationData]).select();

    loadingModal.hide();

    if (error) {
        showAlert('danger', `Application failed: ${error.message}`);
    } else if (data) {
        // MOCK: Create a fake result for now
        const mockResult = {
            decision: 'APPROVED',
            report: {
                application_id: data[0].id,
                applicant_info: { name: document.getElementById('name').value },
                financial_info: { loan_amount: applicationData.loan_amount, credit_score: applicationData.cibil_score },
                ai_ml_analysis: { prediction: 'Approve', probability: '0.85' },
                fuzzy_logic_analysis: { decision: 'High', score: '92' },
                recommendations: ['Loan approved with standard interest rate.'],
            }
        };
        displayLoanResult(mockResult);
        fetchApplicationHistory(); // Refresh history table
        resetForm();
    }
}

async function fetchApplicationHistory() {
    if (!currentUser) return;
    const { data, error } = await supabase
        .from('loan_applications')
        .select('id, created_at, loan_amount, status')
        .eq('user_id', currentUser.id)
        .order('created_at', { ascending: false });

    const tableBody = document.getElementById('applicationHistoryTable');
    if (error) {
        tableBody.innerHTML = `<tr><td colspan="5" class="text-center text-danger">Failed to load history.</td></tr>`;
    } else if (data && data.length > 0) {
        tableBody.innerHTML = data.map(app => `
            <tr>
                <td>${app.id.substring(0, 8)}...</td>
                <td>${new Date(app.created_at).toLocaleDateString()}</td>
                <td>₹${Number(app.loan_amount).toLocaleString('en-IN')}</td>
                <td><span class="badge bg-warning">${app.status}</span></td>
                <td><button class="btn btn-sm btn-primary">View</button></td>
            </tr>
        `).join('');
    } else {
        tableBody.innerHTML = `<tr><td colspan="5" class="text-center text-muted py-4">
            <i class="fas fa-inbox fa-2x mb-2"></i><br>No applications found.
        </td></tr>`;
    }
}

async function handleChangePassword(e) {
    e.preventDefault();
    if (!validateForm('changePasswordForm')) return;
    const newPassword = document.getElementById('newPassword').value;

    const { error } = await supabase.auth.updateUser({ password: newPassword });

    if (error) {
        showAlert('danger', `Failed to change password: ${error.message}`);
    } else {
        showAlert('success', 'Password changed successfully!');
        e.target.reset();
    }
}

// --- Global & Utility Functions ---
window.showSection = (sectionName) => {
    document.querySelectorAll('.content-section').forEach(s => s.style.display = 'none');
    const target = document.getElementById(sectionName + '-section');
    if (target) target.style.display = 'block';
    
    document.querySelectorAll('.sidebar-nav .nav-link').forEach(l => l.classList.remove('active'));
    const activeLink = document.querySelector(`.sidebar-nav [onclick="window.showSection('${sectionName}')"]`);
    if (activeLink) activeLink.classList.add('active');
};

window.resetForm = () => {
    const form = document.getElementById('loanApplicationForm');
    if (form) form.reset();
};

window.printResult = () => window.print();
window.scrollToFeatures = () => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' });

function displayLoanResult(result) {
    const resultContent = document.getElementById('resultContent');
    const { report, decision } = result;
    const decisionClass = decision === 'APPROVED' ? 'success' : 'danger';
    const decisionIcon = decision === 'APPROVED' ? 'check-circle' : 'times-circle';

    resultContent.innerHTML = `
        <div class="alert alert-${decisionClass}">
            <h4 class="alert-heading"><i class="fas fa-${decisionIcon} me-2"></i> ${decision}</h4>
        </div>
        <h5>Application ID: ${report.application_id}</h5>
        <p><strong>Applicant:</strong> ${report.applicant_info.name}</p>
        <p><strong>Loan Amount:</strong> ₹${Number(report.financial_info.loan_amount).toLocaleString('en-IN')}</p>
        <hr>
        <h5>Analysis</h5>
        <p><strong>AI/ML Prediction:</strong> ${report.ai_ml_analysis.prediction} (Confidence: ${(report.ai_ml_analysis.probability * 100).toFixed(0)}%)</p>
        <p><strong>Fuzzy Logic Score:</strong> ${report.fuzzy_logic_analysis.score} (${report.fuzzy_logic_analysis.decision})</p>
    `;
    new bootstrap.Modal(document.getElementById('resultModal')).show();
}

function showAlert(type, message) {
    const container = document.getElementById('alertContainer') || createAlertContainer();
    const icon = type === 'success' ? 'check-circle' : 'exclamation-circle';
    const alertHtml = `
        <div class="alert alert-${type} alert-dismissible fade show" role="alert">
            <i class="fas fa-${icon} me-2"></i> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>`;
    container.insertAdjacentHTML('beforeend', alertHtml);
    setTimeout(() => bootstrap.Alert.getOrCreateInstance(container.lastElementChild)?.close(), 5000);
}

function createAlertContainer() {
    const container = document.createElement('div');
    container.id = 'alertContainer';
    container.className = 'position-fixed top-0 end-0 p-3';
    container.style.zIndex = '1056';
    document.body.appendChild(container);
    return container;
}

function validateForm(formId) {
    const form = document.getElementById(formId);
    let isValid = true;
    form.querySelectorAll('[required]').forEach(field => {
        if (!field.checkValidity()) {
            field.classList.add('is-invalid');
            isValid = false;
        } else {
            field.classList.remove('is-invalid');
            field.classList.add('is-valid');
        }
    });
    return isValid;
}

function initializePasswordToggles() {
    document.querySelectorAll('.password-toggle').forEach(toggle => {
        toggle.addEventListener('click', () => {
            const input = toggle.previousElementSibling;
            input.type = input.type === 'password' ? 'text' : 'password';
            toggle.querySelector('i').classList.toggle('fa-eye');
            toggle.querySelector('i').classList.toggle('fa-eye-slash');
        });
    });
}
