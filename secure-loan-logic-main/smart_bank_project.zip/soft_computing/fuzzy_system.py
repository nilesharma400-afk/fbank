import numpy as np
import matplotlib.pyplot as plt
import json
import os

# Simple fuzzy logic implementation without skfuzzy dependency
class FuzzyLoanSystem:
    """
    Fuzzy Logic System for Credit Scoring and Loan Approval
    Implements fuzzy inference system for decision making
    """
    
    def __init__(self):
        self.rules = []
        
    def build_fuzzy_system(self):
        """
        Build the fuzzy inference system with rules
        """
        # Define fuzzy rules for loan approval
        self.rules = [
            # High credit score rules
            {'credit_score': 'excellent', 'income_ratio': 'low', 'employment': 'stable', 'decision': 'approve', 'weight': 0.9},
            {'credit_score': 'excellent', 'income_ratio': 'moderate', 'employment': 'stable', 'decision': 'approve', 'weight': 0.8},
            {'credit_score': 'excellent', 'income_ratio': 'high', 'employment': 'stable', 'decision': 'conditional', 'weight': 0.6},
            
            # Good credit score rules
            {'credit_score': 'good', 'income_ratio': 'low', 'employment': 'stable', 'decision': 'approve', 'weight': 0.8},
            {'credit_score': 'good', 'income_ratio': 'moderate', 'employment': 'moderate', 'decision': 'conditional', 'weight': 0.6},
            {'credit_score': 'good', 'income_ratio': 'high', 'employment': 'any', 'decision': 'reject', 'weight': 0.3},
            
            # Fair credit score rules
            {'credit_score': 'fair', 'income_ratio': 'low', 'employment': 'stable', 'decision': 'conditional', 'weight': 0.5},
            {'credit_score': 'fair', 'income_ratio': 'moderate', 'employment': 'any', 'decision': 'reject', 'weight': 0.3},
            {'credit_score': 'fair', 'income_ratio': 'high', 'employment': 'any', 'decision': 'reject', 'weight': 0.2},
            
            # Poor credit score rules
            {'credit_score': 'poor', 'income_ratio': 'any', 'employment': 'any', 'decision': 'reject', 'weight': 0.1},
        ]
        
    def _get_credit_category(self, credit_score):
        """Get credit score category"""
        if credit_score >= 750:
            return 'excellent'
        elif credit_score >= 650:
            return 'good'
        elif credit_score >= 600:
            return 'fair'
        else:
            return 'poor'
    
    def _get_income_category(self, income_ratio):
        """Get income ratio category"""
        if income_ratio <= 0.3:
            return 'low'
        elif income_ratio <= 0.5:
            return 'moderate'
        else:
            return 'high'
    
    def _get_employment_category(self, employment_years):
        """Get employment stability category"""
        if employment_years >= 10:
            return 'stable'
        elif employment_years >= 5:
            return 'moderate'
        else:
            return 'unstable'
    
    def evaluate_loan(self, cibil_score, monthly_income, monthly_debt, employment_years, loan_amount, max_loan_amount):
        """
        Evaluate loan application using fuzzy logic
        """
        # Calculate income ratio
        income_ratio = monthly_debt / (monthly_income + 1e-6)
        
        # Get categories
        credit_category = self._get_credit_category(cibil_score)
        income_category = self._get_income_category(income_ratio)
        employment_category = self._get_employment_category(employment_years)
        
        # Find matching rules
        matching_rules = []
        for rule in self.rules:
            if (rule['credit_score'] == credit_category or rule['credit_score'] == 'any') and \
               (rule['income_ratio'] == income_category or rule['income_ratio'] == 'any') and \
               (rule['employment'] == employment_category or rule['employment'] == 'any'):
                matching_rules.append(rule)
        
        if not matching_rules:
            # Default rule
            matching_rules = [{'decision': 'reject', 'weight': 0.1}]
        
        # Calculate weighted decision
        total_weight = sum(rule['weight'] for rule in matching_rules)
        weighted_score = sum(rule['weight'] * self._get_decision_score(rule['decision']) for rule in matching_rules)
        
        if total_weight > 0:
            final_score = (weighted_score / total_weight) * 100
        else:
            final_score = 30  # Default moderate score
        
        # Determine decision
        if final_score >= 60:
            decision = "APPROVE"
        elif final_score >= 30:
            decision = "CONDITIONAL"
        else:
            decision = "REJECT"
        
        return {
            'decision': decision,
            'score': final_score,
            'confidence': self._calculate_confidence(final_score),
            'reasoning': self._get_reasoning(cibil_score, income_ratio, employment_years),
            'matching_rules': len(matching_rules)
        }
    
    def _get_decision_score(self, decision):
        """Convert decision to numeric score"""
        if decision == 'approve':
            return 80
        elif decision == 'conditional':
            return 50
        else:
            return 20
    
    def _calculate_confidence(self, score):
        """Calculate confidence level based on approval score"""
        if score >= 80 or score <= 20:
            return "High"
        elif score >= 60 or score <= 40:
            return "Medium"
        else:
            return "Low"
    
    def _get_reasoning(self, cibil_score, income_ratio, employment_years):
        """Generate reasoning for the decision"""
        reasons = []
        
        if cibil_score >= 750:
            reasons.append("Excellent CIBIL score")
        elif cibil_score >= 700:
            reasons.append("Good CIBIL score")
        elif cibil_score >= 650:
            reasons.append("Fair CIBIL score")
        else:
            reasons.append("Poor CIBIL score")
        
        if income_ratio <= 0.3:
            reasons.append("Low debt-to-income ratio")
        elif income_ratio <= 0.5:
            reasons.append("Moderate debt-to-income ratio")
        else:
            reasons.append("High debt-to-income ratio")
        
        if employment_years >= 10:
            reasons.append("Stable employment history")
        elif employment_years >= 5:
            reasons.append("Moderate employment stability")
        else:
            reasons.append("Limited employment history")
        
        return "; ".join(reasons)
    
    def visualize_membership_functions(self, save_path=None):
        """
        Visualize membership functions
        """
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # Credit Score membership functions
        credit_scores = np.linspace(300, 850, 100)
        poor = np.maximum(0, np.minimum(1, (500 - credit_scores) / 200))
        fair = np.maximum(0, np.minimum(1, np.minimum((credit_scores - 400) / 100, (600 - credit_scores) / 100)))
        good = np.maximum(0, np.minimum(1, np.minimum((credit_scores - 550) / 100, (750 - credit_scores) / 100)))
        excellent = np.maximum(0, np.minimum(1, (credit_scores - 700) / 150))
        
        axes[0, 0].plot(credit_scores, poor, 'r-', label='Poor')
        axes[0, 0].plot(credit_scores, fair, 'y-', label='Fair')
        axes[0, 0].plot(credit_scores, good, 'g-', label='Good')
        axes[0, 0].plot(credit_scores, excellent, 'b-', label='Excellent')
        axes[0, 0].set_title('Credit Score Membership Functions')
        axes[0, 0].legend()
        axes[0, 0].grid(True)
        
        # Income Ratio membership functions
        income_ratios = np.linspace(0, 1, 100)
        low_debt = np.maximum(0, np.minimum(1, (0.4 - income_ratios) / 0.4))
        moderate_debt = np.maximum(0, np.minimum(1, np.minimum((income_ratios - 0.3) / 0.2, (0.6 - income_ratios) / 0.2)))
        high_debt = np.maximum(0, np.minimum(1, (income_ratios - 0.5) / 0.5))
        
        axes[0, 1].plot(income_ratios, low_debt, 'g-', label='Low Debt')
        axes[0, 1].plot(income_ratios, moderate_debt, 'y-', label='Moderate Debt')
        axes[0, 1].plot(income_ratios, high_debt, 'r-', label='High Debt')
        axes[0, 1].set_title('Income Ratio Membership Functions')
        axes[0, 1].legend()
        axes[0, 1].grid(True)
        
        # Employment Stability membership functions
        employment_years = np.linspace(0, 30, 100)
        unstable = np.maximum(0, np.minimum(1, (5 - employment_years) / 5))
        moderate = np.maximum(0, np.minimum(1, np.minimum((employment_years - 3) / 5, (15 - employment_years) / 7)))
        stable = np.maximum(0, np.minimum(1, (employment_years - 10) / 10))
        
        axes[1, 0].plot(employment_years, unstable, 'r-', label='Unstable')
        axes[1, 0].plot(employment_years, moderate, 'y-', label='Moderate')
        axes[1, 0].plot(employment_years, stable, 'g-', label='Stable')
        axes[1, 0].set_title('Employment Stability Membership Functions')
        axes[1, 0].legend()
        axes[1, 0].grid(True)
        
        # Approval Decision membership functions
        approval_scores = np.linspace(0, 100, 100)
        reject = np.maximum(0, np.minimum(1, (40 - approval_scores) / 40))
        conditional = np.maximum(0, np.minimum(1, np.minimum((approval_scores - 30) / 20, (70 - approval_scores) / 20)))
        approve = np.maximum(0, np.minimum(1, (approval_scores - 60) / 40))
        
        axes[1, 1].plot(approval_scores, reject, 'r-', label='Reject')
        axes[1, 1].plot(approval_scores, conditional, 'y-', label='Conditional')
        axes[1, 1].plot(approval_scores, approve, 'g-', label='Approve')
        axes[1, 1].set_title('Approval Decision Membership Functions')
        axes[1, 1].legend()
        axes[1, 1].grid(True)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        return fig
    
    def save_system(self, filepath):
        """
        Save fuzzy system configuration
        """
        config = {
            'rules': self.rules,
            'system_type': 'simplified_fuzzy_logic'
        }
        
        with open(filepath, 'w') as f:
            json.dump(config, f, indent=2)
    
    def load_system(self, filepath):
        """
        Load fuzzy system configuration
        """
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                config = json.load(f)
            self.rules = config.get('rules', [])
            return config
        else:
            raise FileNotFoundError(f"Configuration file not found: {filepath}")
