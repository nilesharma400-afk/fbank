import numpy as np
import random
import matplotlib.pyplot as plt
import json
import os

# Simple genetic algorithm implementation without deap dependency
class GeneticAlgorithmOptimizer:
    """
    Genetic Algorithm for optimizing loan approval parameters
    Implements evolutionary computation for parameter tuning
    """
    
    def __init__(self, population_size=50, generations=100):
        self.population_size = population_size
        self.generations = generations
        self.best_individual = None
        self.best_fitness = None
        self.fitness_history = []
        
    def _generate_individual(self):
        """Generate a random individual (parameter set)"""
        return [random.uniform(0.0, 1.0) for _ in range(5)]
    
    def _generate_population(self):
        """Generate initial population"""
        return [self._generate_individual() for _ in range(self.population_size)]
    
    def _evaluate_individual(self, individual):
        """
        Evaluate fitness of an individual (parameter set)
        """
        # Normalize weights to sum to 1
        weights = np.array(individual)
        weights = weights / np.sum(weights)
        
        # Simulate loan approval accuracy using these weights
        fitness = self._simulate_loan_accuracy(weights)
        
        return fitness
    
    def _simulate_loan_accuracy(self, weights):
        """
        Simulate loan approval accuracy based on parameter weights
        """
        # Generate synthetic loan data
        n_samples = 1000
        np.random.seed(42)
        
        # Generate features
        cibil_scores = np.random.normal(700, 100, n_samples)
        income_ratios = np.random.beta(2, 5, n_samples)  # Skewed towards lower ratios
        employment_years = np.random.exponential(5, n_samples)
        debt_ratios = np.random.beta(3, 7, n_samples)
        ages = np.random.normal(35, 10, n_samples)
        
        # Normalize features
        cibil_scores = np.clip(cibil_scores, 300, 900) / 900.0
        employment_years = np.clip(employment_years, 0, 30) / 30.0
        ages = np.clip(ages, 22, 65) / 65.0
        
        # Calculate weighted scores
        scores = (weights[0] * cibil_scores + 
                 weights[1] * (1 - income_ratios) +  # Lower income ratio is better
                 weights[2] * employment_years +
                 weights[3] * (1 - debt_ratios) +    # Lower debt ratio is better
                 weights[4] * ages)
        
        # Generate true labels based on business rules
        true_labels = ((cibil_scores >= 0.7) & 
                      (income_ratios <= 0.4) & 
                      (employment_years >= 0.2) & 
                      (debt_ratios <= 0.3)).astype(int)
        
        # Calculate accuracy
        predicted_labels = (scores >= 0.5).astype(int)
        accuracy = np.mean(predicted_labels == true_labels)
        
        return accuracy
    
    def _crossover(self, parent1, parent2):
        """Perform crossover between two parents"""
        child1 = parent1.copy()
        child2 = parent2.copy()
        
        # Single point crossover
        crossover_point = random.randint(1, len(parent1) - 1)
        
        child1[crossover_point:] = parent2[crossover_point:]
        child2[crossover_point:] = parent1[crossover_point:]
        
        return child1, child2
    
    def _mutate(self, individual, mutation_rate=0.1):
        """Mutate an individual"""
        mutated = individual.copy()
        
        for i in range(len(mutated)):
            if random.random() < mutation_rate:
                mutated[i] = random.uniform(0.0, 1.0)
        
        return mutated
    
    def _tournament_selection(self, population, fitness_scores, tournament_size=3):
        """Select individuals using tournament selection"""
        selected = []
        
        for _ in range(len(population)):
            # Randomly select tournament participants
            tournament_indices = random.sample(range(len(population)), tournament_size)
            tournament_fitness = [fitness_scores[i] for i in tournament_indices]
            
            # Select the best from tournament
            winner_index = tournament_indices[np.argmax(tournament_fitness)]
            selected.append(population[winner_index])
        
        return selected
    
    def run_optimization(self):
        """
        Run the genetic algorithm optimization
        """
        # Initialize population
        population = self._generate_population()
        
        # Evolution loop
        for generation in range(self.generations):
            # Evaluate fitness
            fitness_scores = [self._evaluate_individual(ind) for ind in population]
            
            # Track best individual
            best_idx = np.argmax(fitness_scores)
            if self.best_individual is None or fitness_scores[best_idx] > self.best_fitness:
                self.best_individual = population[best_idx].copy()
                self.best_fitness = fitness_scores[best_idx]
            
            # Record fitness statistics
            avg_fitness = np.mean(fitness_scores)
            max_fitness = np.max(fitness_scores)
            self.fitness_history.append({
                'generation': generation,
                'avg_fitness': avg_fitness,
                'max_fitness': max_fitness,
                'min_fitness': np.min(fitness_scores)
            })
            
            # Selection
            selected = self._tournament_selection(population, fitness_scores)
            
            # Create new population
            new_population = []
            
            for i in range(0, len(selected), 2):
                if i + 1 < len(selected):
                    # Crossover
                    child1, child2 = self._crossover(selected[i], selected[i + 1])
                    
                    # Mutation
                    child1 = self._mutate(child1)
                    child2 = self._mutate(child2)
                    
                    new_population.extend([child1, child2])
                else:
                    # If odd number, add the last individual
                    new_population.append(self._mutate(selected[i]))
            
            population = new_population[:self.population_size]
        
        return population, self.fitness_history
    
    def get_optimized_parameters(self):
        """
        Get the best parameter set found by the genetic algorithm
        """
        if self.best_individual is None:
            raise ValueError("Optimization must be run first")
        
        weights = np.array(self.best_individual)
        weights = weights / np.sum(weights)  # Normalize to sum to 1
        
        return {
            'credit_score_weight': weights[0],
            'income_weight': weights[1],
            'employment_weight': weights[2],
            'debt_weight': weights[3],
            'age_weight': weights[4],
            'fitness_score': self.best_fitness
        }
    
    def plot_evolution(self, save_path=None):
        """
        Plot the evolution of fitness over generations
        """
        if not self.fitness_history:
            raise ValueError("Optimization must be run first")
        
        generations = [h['generation'] for h in self.fitness_history]
        avg_fitness = [h['avg_fitness'] for h in self.fitness_history]
        max_fitness = [h['max_fitness'] for h in self.fitness_history]
        
        plt.figure(figsize=(10, 6))
        plt.plot(generations, max_fitness, 'b-', label='Best Fitness')
        plt.plot(generations, avg_fitness, 'r-', label='Average Fitness')
        plt.xlabel('Generation')
        plt.ylabel('Fitness')
        plt.title('Genetic Algorithm Evolution')
        plt.legend()
        plt.grid(True)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        return plt.gcf()
    
    def save_results(self, filepath):
        """
        Save optimization results
        """
        if self.best_individual is None:
            raise ValueError("No results to save")
        
        results = {
            'best_parameters': self.get_optimized_parameters(),
            'evolution_data': self.fitness_history,
            'algorithm_settings': {
                'population_size': self.population_size,
                'generations': self.generations
            }
        }
        
        with open(filepath, 'w') as f:
            json.dump(results, f, indent=2)
    
    def load_results(self, filepath):
        """
        Load optimization results
        """
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                results = json.load(f)
            return results
        else:
            raise FileNotFoundError(f"Results file not found: {filepath}")

class HybridSoftComputingSystem:
    """
    Hybrid system combining Fuzzy Logic and Genetic Algorithm
    """
    
    def __init__(self):
        from .fuzzy_system import FuzzyLoanSystem
        self.fuzzy_system = FuzzyLoanSystem()
        self.ga_optimizer = GeneticAlgorithmOptimizer()
        self.optimized_weights = None
        
    def optimize_fuzzy_parameters(self):
        """
        Use genetic algorithm to optimize fuzzy system parameters
        """
        # Run genetic algorithm optimization
        population, history = self.ga_optimizer.run_optimization()
        
        # Get optimized parameters
        self.optimized_weights = self.ga_optimizer.get_optimized_parameters()
        
        return self.optimized_weights
    
    def evaluate_loan_hybrid(self, application_data):
        """
        Evaluate loan using hybrid fuzzy-genetic system
        """
        # Get fuzzy system evaluation
        fuzzy_result = self.fuzzy_system.evaluate_loan(
            application_data['cibil_score'],
            application_data['monthly_income'],
            application_data['monthly_debt'],
            application_data['employment_years'],
            application_data['loan_amount'],
            application_data.get('max_loan_amount', 2000000)
        )
        
        # Apply genetic algorithm optimized weights if available
        if self.optimized_weights:
            # Adjust fuzzy score based on optimized weights
            adjusted_score = self._apply_optimized_weights(application_data, fuzzy_result['score'])
            fuzzy_result['adjusted_score'] = adjusted_score
            
            # Update decision based on adjusted score
            if adjusted_score >= 60:
                fuzzy_result['final_decision'] = "APPROVE"
            elif adjusted_score >= 30:
                fuzzy_result['final_decision'] = "CONDITIONAL"
            else:
                fuzzy_result['final_decision'] = "REJECT"
        
        return fuzzy_result
    
    def _apply_optimized_weights(self, application_data, fuzzy_score):
        """
        Apply genetic algorithm optimized weights to fuzzy score
        """
        if not self.optimized_weights:
            return fuzzy_score
        
        # Calculate weighted components
        cibil_component = (application_data['cibil_score'] / 900.0) * self.optimized_weights['credit_score_weight']
        income_component = (1 - application_data['monthly_debt'] / application_data['monthly_income']) * self.optimized_weights['income_weight']
        employment_component = (application_data['employment_years'] / 30.0) * self.optimized_weights['employment_weight']
        
        # Combine with fuzzy score
        weighted_score = (fuzzy_score * 0.7 + 
                         (cibil_component + income_component + employment_component) * 100 * 0.3)
        
        return min(100, max(0, weighted_score))
    
    def get_system_performance(self):
        """
        Get overall system performance metrics
        """
        if self.optimized_weights:
            return {
                'optimization_fitness': self.optimized_weights['fitness_score'],
                'parameter_weights': self.optimized_weights,
                'system_type': 'Hybrid Fuzzy-Genetic'
            }
        else:
            return {
                'system_type': 'Fuzzy Logic Only',
                'status': 'Not optimized'
            }
