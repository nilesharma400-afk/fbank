import pandas as pd
import numpy as np
import json
from datetime import datetime
import os

class DataProcessor:
    """
    Data processing utilities for loan applications
    """
    
    @staticmethod
    def validate_loan_data(data):
        """
        Validate loan application data
        """
        errors = []
        
        # Required fields
        required_fields = [
            'name', 'age', 'monthly_income', 'monthly_debt', 
            'credit_score', 'loan_amount', 'employment_years'
        ]
        
        for field in required_fields:
            if field not in data or data[field] is None or data[field] == '':
                errors.append(f"{field} is required")
        
        # Numeric validations
        numeric_fields = {
            'age': (18, 100),
            'monthly_income': (0, 1000000),
            'monthly_debt': (0, 100000),
            'credit_score': (300, 850),
            'loan_amount': (10000, 10000000),
            'employment_years': (0, 50)
        }
        
        for field, (min_val, max_val) in numeric_fields.items():
            if field in data:
                try:
                    value = float(data[field])
                    if value < min_val or value > max_val:
                        errors.append(f"{field} must be between {min_val} and {max_val}")
                except (ValueError, TypeError):
                    errors.append(f"{field} must be a valid number")
        
        return errors
    
    @staticmethod
    def calculate_risk_factors(data):
        """
        Calculate risk factors for loan application
        """
        risk_factors = {}
        
        # Debt-to-Income Ratio
        if data.get('monthly_income', 0) > 0:
            risk_factors['debt_to_income_ratio'] = data['monthly_debt'] / data['monthly_income']
        else:
            risk_factors['debt_to_income_ratio'] = 1.0
        
        # Loan-to-Value Ratio (if property value provided)
        if data.get('property_value', 0) > 0:
            risk_factors['loan_to_value_ratio'] = data['loan_amount'] / data['property_value']
        else:
            risk_factors['loan_to_value_ratio'] = 0.8  # Default assumption
        
        # Credit Score Risk
        credit_score = data.get('credit_score', 300)
        if credit_score >= 750:
            risk_factors['credit_risk'] = 'Low'
        elif credit_score >= 650:
            risk_factors['credit_risk'] = 'Medium'
        else:
            risk_factors['credit_risk'] = 'High'
        
        # Employment Stability
        employment_years = data.get('employment_years', 0)
        if employment_years >= 5:
            risk_factors['employment_stability'] = 'Stable'
        elif employment_years >= 2:
            risk_factors['employment_stability'] = 'Moderate'
        else:
            risk_factors['employment_stability'] = 'Unstable'
        
        return risk_factors
    
    @staticmethod
    def generate_application_id():
        """
        Generate unique application ID
        """
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        random_suffix = np.random.randint(1000, 9999)
        return f"LA{timestamp}{random_suffix}"
    
    @staticmethod
    def format_currency(amount):
        """
        Format amount as currency
        """
        return f"₹{amount:,.2f}"
    
    @staticmethod
    def format_percentage(value):
        """
        Format value as percentage
        """
        return f"{value:.2f}%"

class ReportGenerator:
    """
    Generate loan approval reports
    """
    
    @staticmethod
    def generate_approval_report(application_data, ai_result, fuzzy_result, final_decision):
        """
        Generate comprehensive loan approval report
        """
        report = {
            'application_id': DataProcessor.generate_application_id(),
            'timestamp': datetime.now().isoformat(),
            'applicant_info': {
                'name': application_data.get('name', 'N/A'),
                'age': application_data.get('age', 'N/A'),
                'employment_years': application_data.get('employment_years', 'N/A')
            },
            'financial_info': {
                'monthly_income': DataProcessor.format_currency(application_data.get('monthly_income', 0)),
                'monthly_debt': DataProcessor.format_currency(application_data.get('monthly_debt', 0)),
                'loan_amount': DataProcessor.format_currency(application_data.get('loan_amount', 0)),
                'credit_score': application_data.get('credit_score', 'N/A')
            },
            'risk_assessment': DataProcessor.calculate_risk_factors(application_data),
            'ai_ml_analysis': {
                'prediction': 'APPROVED' if ai_result.get('final_prediction', 0) == 1 else 'REJECTED',
                'probability': f"{ai_result.get('final_probability', 0):.2%}",
                'risk_level': ai_result.get('risk_level', 'Unknown')
            },
            'fuzzy_logic_analysis': {
                'decision': fuzzy_result.get('decision', 'Unknown'),
                'score': f"{fuzzy_result.get('score', 0):.1f}/100",
                'confidence': fuzzy_result.get('confidence', 'Unknown'),
                'reasoning': fuzzy_result.get('reasoning', 'No reasoning provided')
            },
            'final_decision': final_decision,
            'recommendations': ReportGenerator._generate_recommendations(application_data, final_decision)
        }
        
        return report
    
    @staticmethod
    def _generate_recommendations(application_data, decision):
        """
        Generate recommendations based on decision
        """
        recommendations = []
        
        if decision == 'APPROVED':
            recommendations.append("Congratulations! Your loan application has been approved.")
            recommendations.append("Please review the loan terms and conditions carefully.")
        elif decision == 'CONDITIONAL':
            recommendations.append("Your loan application requires additional review.")
            recommendations.append("Consider providing additional documentation or collateral.")
        else:
            recommendations.append("Your loan application has been declined.")
            
            # Specific recommendations based on risk factors
            if application_data.get('credit_score', 0) < 650:
                recommendations.append("Improve your credit score by paying bills on time.")
            
            if application_data.get('monthly_debt', 0) / application_data.get('monthly_income', 1) > 0.4:
                recommendations.append("Reduce your debt-to-income ratio by paying down existing debts.")
            
            if application_data.get('employment_years', 0) < 2:
                recommendations.append("Establish longer employment history before reapplying.")
        
        return recommendations
    
    @staticmethod
    def save_report(report, filepath):
        """
        Save report to file
        """
        with open(filepath, 'w') as f:
            json.dump(report, f, indent=2)
    
    @staticmethod
    def load_report(filepath):
        """
        Load report from file
        """
        with open(filepath, 'r') as f:
            return json.load(f)

class SystemMonitor:
    """
    System monitoring and performance tracking
    """
    
    def __init__(self):
        self.performance_metrics = {
            'total_applications': 0,
            'approved_applications': 0,
            'rejected_applications': 0,
            'conditional_applications': 0,
            'average_processing_time': 0,
            'system_uptime': datetime.now()
        }
        self.processing_times = []
    
    def record_application(self, decision, processing_time):
        """
        Record application processing
        """
        self.performance_metrics['total_applications'] += 1
        
        if decision == 'APPROVED':
            self.performance_metrics['approved_applications'] += 1
        elif decision == 'REJECTED':
            self.performance_metrics['rejected_applications'] += 1
        elif decision == 'CONDITIONAL':
            self.performance_metrics['conditional_applications'] += 1
        
        self.processing_times.append(processing_time)
        
        # Update average processing time
        self.performance_metrics['average_processing_time'] = np.mean(self.processing_times)
    
    def get_performance_summary(self):
        """
        Get system performance summary
        """
        total = self.performance_metrics['total_applications']
        
        if total == 0:
            return self.performance_metrics
        
        summary = self.performance_metrics.copy()
        summary['approval_rate'] = self.performance_metrics['approved_applications'] / total
        summary['rejection_rate'] = self.performance_metrics['rejected_applications'] / total
        summary['conditional_rate'] = self.performance_metrics['conditional_applications'] / total
        
        return summary
    
    def get_system_health(self):
        """
        Get system health status
        """
        uptime = datetime.now() - self.performance_metrics['system_uptime']
        
        health_status = {
            'status': 'Healthy',
            'uptime_hours': uptime.total_seconds() / 3600,
            'total_applications_processed': self.performance_metrics['total_applications'],
            'average_processing_time': self.performance_metrics['average_processing_time'],
            'last_updated': datetime.now().isoformat()
        }
        
        # Check for potential issues
        if self.performance_metrics['average_processing_time'] > 10:
            health_status['status'] = 'Warning - Slow Processing'
        
        if self.performance_metrics['total_applications'] == 0:
            health_status['status'] = 'No Activity'
        
        return health_status
