import os
import hashlib
import secrets
import re
from datetime import datetime, timedelta
import json

class AuthenticationSystem:
    """
    Authentication System for Loan Advisor
    Implements secure user authentication and session management
    """
    
    def __init__(self):
        self.users = {}
        self.sessions = {}
        self.failed_attempts = {}
        self.max_attempts = 5
        self.session_timeout = 3600  # 1 hour
    
    def register_user(self, username, password, user_type="customer"):
        """
        Register a new user
        """
        if username in self.users:
            return False, "Username already exists"
        
        # Validate password strength
        if not self._validate_password(password):
            return False, "Password does not meet security requirements"
        
        # Hash password
        password_hash = self._hash_password(password)
        
        self.users[username] = {
            'password_hash': password_hash,
            'user_type': user_type,
            'created_at': datetime.now(),
            'is_active': True
        }
        
        return True, "User registered successfully"
    
    def authenticate_user(self, username, password, ip_address=None):
        """
        Authenticate user login
        """
        if username not in self.users:
            return False, "Invalid credentials"
        
        user = self.users[username]
        
        # Check if account is locked
        if self._is_account_locked(username):
            return False, "Account locked due to too many failed attempts"
        
        # Verify password
        if not self._verify_password(password, user['password_hash']):
            self._record_failed_attempt(username, ip_address)
            return False, "Invalid credentials"
        
        # Reset failed attempts on successful login
        if username in self.failed_attempts:
            del self.failed_attempts[username]
        
        # Create session
        session_token = self._create_session(username)
        
        return True, session_token
    
    def _validate_password(self, password):
        """
        Validate password strength
        """
        if len(password) < 8:
            return False
        
        if not re.search(r'[A-Z]', password):
            return False
        
        if not re.search(r'[a-z]', password):
            return False
        
        if not re.search(r'\d', password):
            return False
        
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            return False
        
        return True
    
    def _hash_password(self, password):
        """
        Hash password using SHA-256 with salt
        """
        salt = secrets.token_hex(32)
        password_hash = hashlib.sha256((password + salt).encode()).hexdigest()
        return f"{salt}:{password_hash}"
    
    def _verify_password(self, password, stored_hash):
        """
        Verify password against stored hash
        """
        salt, hash_value = stored_hash.split(':')
        password_hash = hashlib.sha256((password + salt).encode()).hexdigest()
        return password_hash == hash_value
    
    def _create_session(self, username):
        """
        Create user session
        """
        session_token = secrets.token_urlsafe(32)
        session_data = {
            'username': username,
            'created_at': datetime.now(),
            'last_activity': datetime.now(),
            'is_active': True
        }
        self.sessions[session_token] = session_data
        return session_token
    
    def validate_session(self, session_token):
        """
        Validate session token
        """
        if session_token not in self.sessions:
            return False
        
        session = self.sessions[session_token]
        
        # Check if session is expired
        if datetime.now() - session['last_activity'] > timedelta(seconds=self.session_timeout):
            del self.sessions[session_token]
            return False
        
        # Update last activity
        session['last_activity'] = datetime.now()
        return session['username']
    
    def logout_user(self, session_token):
        """
        Logout user
        """
        if session_token in self.sessions:
            del self.sessions[session_token]
    
    def _record_failed_attempt(self, username, ip_address):
        """
        Record failed login attempt
        """
        if username not in self.failed_attempts:
            self.failed_attempts[username] = []
        
        self.failed_attempts[username].append({
            'timestamp': datetime.now(),
            'ip_address': ip_address
        })
        
        # Remove old attempts (older than 1 hour)
        cutoff = datetime.now() - timedelta(hours=1)
        self.failed_attempts[username] = [
            attempt for attempt in self.failed_attempts[username] 
            if attempt['timestamp'] > cutoff
        ]
    
    def _is_account_locked(self, username):
        """
        Check if account is locked
        """
        if username not in self.failed_attempts:
            return False
        
        recent_attempts = len(self.failed_attempts[username])
        return recent_attempts >= self.max_attempts
    
    def get_user_info(self, username):
        """
        Get user information
        """
        if username not in self.users:
            return None
        
        user = self.users[username].copy()
        del user['password_hash']  # Remove sensitive data
        return user
    
    def change_password(self, username, old_password, new_password):
        """
        Change user password
        """
        if username not in self.users:
            return False, "User not found"
        
        user = self.users[username]
        
        # Verify old password
        if not self._verify_password(old_password, user['password_hash']):
            return False, "Current password is incorrect"
        
        # Validate new password
        if not self._validate_password(new_password):
            return False, "New password does not meet security requirements"
        
        # Update password
        user['password_hash'] = self._hash_password(new_password)
        user['password_changed_at'] = datetime.now()
        
        return True, "Password changed successfully"
    
    def get_security_status(self, username):
        """
        Get security status for user
        """
        status = {
            'account_locked': self._is_account_locked(username),
            'failed_attempts': len(self.failed_attempts.get(username, [])),
            'active_sessions': len([s for s in self.sessions.values() if s['username'] == username])
        }
        
        return status
