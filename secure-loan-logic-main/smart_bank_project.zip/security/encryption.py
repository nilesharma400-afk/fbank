import os
import hashlib
import secrets
import re
import base64
from datetime import datetime, timedelta
import json

# Simplified encryption without cryptography dependency
class DataEncryption:
    """
    Data Encryption and Decryption using simple encoding
    Implements basic encryption for sensitive data protection
    """
    
    def __init__(self, key=None):
        if key is None:
            key = secrets.token_urlsafe(32)
        self.key = key
    
    def encrypt_data(self, data):
        """
        Encrypt sensitive data using simple encoding
        """
        if isinstance(data, dict):
            data = json.dumps(data)
        
        # Simple XOR encryption with key
        encrypted = []
        key_bytes = self.key.encode('utf-8')
        
        for i, char in enumerate(data):
            key_char = key_bytes[i % len(key_bytes)]
            encrypted_char = chr(ord(char) ^ key_char)
            encrypted.append(encrypted_char)
        
        encrypted_str = ''.join(encrypted)
        return base64.b64encode(encrypted_str.encode('utf-8')).decode('utf-8')
    
    def decrypt_data(self, encrypted_data):
        """
        Decrypt sensitive data
        """
        encrypted_str = base64.b64decode(encrypted_data.encode('utf-8')).decode('utf-8')
        
        # Simple XOR decryption with key
        decrypted = []
        key_bytes = self.key.encode('utf-8')
        
        for i, char in enumerate(encrypted_str):
            key_char = key_bytes[i % len(key_bytes)]
            decrypted_char = chr(ord(char) ^ key_char)
            decrypted.append(decrypted_char)
        
        return ''.join(decrypted)
    
    def generate_key_from_password(self, password, salt=None):
        """
        Generate encryption key from password using PBKDF2
        """
        if salt is None:
            salt = os.urandom(16)
        
        # Simple key derivation
        key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
        return base64.urlsafe_b64encode(key).decode(), salt.hex()

class SecureAuthentication:
    """
    Secure Authentication System
    Implements password hashing, session management, and access control
    """
    
    def __init__(self):
        self.sessions = {}
        self.failed_attempts = {}
        self.max_attempts = 5
        self.session_timeout = 3600  # 1 hour
    
    def hash_password(self, password, salt=None):
        """
        Hash password using PBKDF2 with salt
        """
        if salt is None:
            salt = os.urandom(32)
        
        password_hash = hashlib.pbkdf2_hmac(
            'sha256',
            password.encode('utf-8'),
            salt,
            100000
        )
        return password_hash.hex(), salt.hex()
    
    def verify_password(self, password, stored_hash, salt):
        """
        Verify password against stored hash
        """
        password_hash, _ = self.hash_password(password, bytes.fromhex(salt))
        return password_hash == stored_hash
    
    def create_session(self, user_id):
        """
        Create secure session for user
        """
        session_token = secrets.token_urlsafe(32)
        session_data = {
            'user_id': user_id,
            'created_at': datetime.now(),
            'last_activity': datetime.now(),
            'is_active': True
        }
        self.sessions[session_token] = session_data
        return session_token
    
    def validate_session(self, session_token):
        """
        Validate session token
        """
        if session_token not in self.sessions:
            return False
        
        session = self.sessions[session_token]
        
        # Check if session is expired
        if datetime.now() - session['last_activity'] > timedelta(seconds=self.session_timeout):
            del self.sessions[session_token]
            return False
        
        # Update last activity
        session['last_activity'] = datetime.now()
        return True
    
    def logout_session(self, session_token):
        """
        Logout user session
        """
        if session_token in self.sessions:
            del self.sessions[session_token]
    
    def record_failed_attempt(self, user_id):
        """
        Record failed login attempt
        """
        if user_id not in self.failed_attempts:
            self.failed_attempts[user_id] = []
        
        self.failed_attempts[user_id].append(datetime.now())
        
        # Remove old attempts (older than 1 hour)
        cutoff = datetime.now() - timedelta(hours=1)
        self.failed_attempts[user_id] = [
            attempt for attempt in self.failed_attempts[user_id] 
            if attempt > cutoff
        ]
    
    def is_account_locked(self, user_id):
        """
        Check if account is locked due to too many failed attempts
        """
        if user_id not in self.failed_attempts:
            return False
        
        recent_attempts = len(self.failed_attempts[user_id])
        return recent_attempts >= self.max_attempts

class InputValidation:
    """
    Input Validation and Sanitization
    Implements security measures against common attacks
    """
    
    def __init__(self):
        self.suspicious_patterns = [
            r'<script.*?>.*?</script>',  # XSS
            r'javascript:',              # XSS
            r'on\w+\s*=',               # XSS
            r'union\s+select',          # SQL Injection
            r'drop\s+table',            # SQL Injection
            r'delete\s+from',           # SQL Injection
            r'insert\s+into',           # SQL Injection
            r'update\s+set',            # SQL Injection
            r'exec\s*\(',               # Command Injection
            r'system\s*\(',             # Command Injection
        ]
    
    def validate_loan_application(self, data):
        """
        Validate loan application data
        """
        errors = []
        
        # Required fields validation
        required_fields = ['name', 'age', 'monthly_income', 'credit_score', 'loan_amount']
        for field in required_fields:
            if field not in data or not data[field]:
                errors.append(f"{field} is required")
        
        # Data type validation
        if 'age' in data:
            try:
                age = int(data['age'])
                if age < 18 or age > 100:
                    errors.append("Age must be between 18 and 100")
            except ValueError:
                errors.append("Age must be a valid number")
        
        if 'monthly_income' in data:
            try:
                income = float(data['monthly_income'])
                if income < 0:
                    errors.append("Monthly income must be positive")
            except ValueError:
                errors.append("Monthly income must be a valid number")
        
        if 'credit_score' in data:
            try:
                score = int(data['credit_score'])
                if score < 300 or score > 850:
                    errors.append("Credit score must be between 300 and 850")
            except ValueError:
                errors.append("Credit score must be a valid number")
        
        # Security validation
        for field, value in data.items():
            if isinstance(value, str):
                if self._contains_suspicious_content(value):
                    errors.append(f"Suspicious content detected in {field}")
        
        return errors
    
    def _contains_suspicious_content(self, text):
        """
        Check for suspicious patterns in text
        """
        text_lower = text.lower()
        for pattern in self.suspicious_patterns:
            if re.search(pattern, text_lower, re.IGNORECASE):
                return True
        return False
    
    def sanitize_input(self, data):
        """
        Sanitize input data
        """
        sanitized = {}
        for key, value in data.items():
            if isinstance(value, str):
                # Remove potentially dangerous characters
                sanitized[key] = re.sub(r'[<>"\']', '', value).strip()
            else:
                sanitized[key] = value
        return sanitized

class SecurityAudit:
    """
    Security Audit and Logging
    Implements security monitoring and audit trails
    """
    
    def __init__(self):
        self.audit_log = []
        self.security_events = []
    
    def log_access_attempt(self, user_id, ip_address, success, details=None):
        """
        Log access attempt
        """
        event = {
            'timestamp': datetime.now().isoformat(),
            'event_type': 'access_attempt',
            'user_id': user_id,
            'ip_address': ip_address,
            'success': success,
            'details': details
        }
        self.audit_log.append(event)
    
    def log_loan_application(self, user_id, application_id, action, details=None):
        """
        Log loan application activity
        """
        event = {
            'timestamp': datetime.now().isoformat(),
            'event_type': 'loan_application',
            'user_id': user_id,
            'application_id': application_id,
            'action': action,
            'details': details
        }
        self.audit_log.append(event)
    
    def log_security_event(self, event_type, severity, description, details=None):
        """
        Log security event
        """
        event = {
            'timestamp': datetime.now().isoformat(),
            'event_type': event_type,
            'severity': severity,
            'description': description,
            'details': details
        }
        self.security_events.append(event)
    
    def get_audit_trail(self, user_id=None, event_type=None, limit=100):
        """
        Get audit trail
        """
        filtered_log = self.audit_log
        
        if user_id:
            filtered_log = [event for event in filtered_log if event.get('user_id') == user_id]
        
        if event_type:
            filtered_log = [event for event in filtered_log if event.get('event_type') == event_type]
        
        return filtered_log[-limit:]
    
    def detect_anomalies(self):
        """
        Detect security anomalies
        """
        anomalies = []
        
        # Check for multiple failed attempts
        failed_attempts = [event for event in self.audit_log 
                          if event.get('event_type') == 'access_attempt' and not event.get('success')]
        
        if len(failed_attempts) > 10:
            anomalies.append({
                'type': 'multiple_failed_attempts',
                'count': len(failed_attempts),
                'severity': 'high'
            })
        
        return anomalies
