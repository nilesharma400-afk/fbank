from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS
import os
import time
from datetime import datetime
import json

# Import our custom modules
from models.loan_model import LoanApprovalModel, generate_sample_data, load_large_dataset
from models.neural_network import RiskAssessmentModel
from soft_computing.fuzzy_system import FuzzyLoanSystem
from soft_computing.genetic_algorithm import HybridSoftComputingSystem
from security.encryption import DataEncryption, InputValidation, SecurityAudit
from security.authentication import AuthenticationSystem
from utils.helpers import DataProcessor, ReportGenerator, SystemMonitor
from config import Config

app = Flask(__name__)
app.config.from_object(Config)
CORS(app)

# Initialize components
auth_system = AuthenticationSystem()
encryption = DataEncryption()
input_validator = InputValidation()
security_audit = SecurityAudit()
system_monitor = SystemMonitor()

# Initialize AI/ML models
risk_model = RiskAssessmentModel()
fuzzy_system = FuzzyLoanSystem()
hybrid_system = HybridSoftComputingSystem()

# Global variables for model state
models_initialized = False

def initialize_models():
    """Initialize and train models"""
    global models_initialized
    
    if models_initialized:
        return
    
    try:
        # Load large dataset for training
        sample_data = load_large_dataset()
        
        # Train risk assessment model
        risk_model.train_models(sample_data)
        
        # Build fuzzy system
        fuzzy_system.build_fuzzy_system()
        
        # Optimize fuzzy parameters using genetic algorithm
        hybrid_system.optimize_fuzzy_parameters()
        
        models_initialized = True
        print("Models initialized successfully")
        
    except Exception as e:
        print(f"Error initializing models: {str(e)}")

@app.route('/')
def index():
    """Main page"""
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        ip_address = request.remote_addr
        
        # Authenticate user
        success, result = auth_system.authenticate_user(username, password, ip_address)
        
        if success:
            session['user_token'] = result
            session['username'] = username
            security_audit.log_access_attempt(username, ip_address, True)
            return jsonify({'success': True, 'message': 'Login successful'})
        else:
            security_audit.log_access_attempt(username, ip_address, False, result)
            return jsonify({'success': False, 'message': result})
    
    return render_template('login.html')

@app.route('/register', methods=['POST'])
def register():
    """User registration"""
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    user_type = data.get('user_type', 'customer')
    
    success, message = auth_system.register_user(username, password, user_type)
    
    return jsonify({'success': success, 'message': message})

@app.route('/logout')
def logout():
    """User logout"""
    if 'user_token' in session:
        auth_system.logout_user(session['user_token'])
        session.clear()
    
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    """User dashboard"""
    if 'user_token' not in session:
        return redirect(url_for('login'))
    
    username = session.get('username')
    return render_template('dashboard.html', username=username)

@app.route('/apply_loan', methods=['POST'])
def apply_loan():
    """Process loan application"""
    start_time = time.time()
    
    if 'user_token' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'})
    
    username = session.get('username')
    
    try:
        # Get application data
        application_data = request.get_json()
        
        # Validate input
        validation_errors = input_validator.validate_loan_application(application_data)
        if validation_errors:
            return jsonify({'success': False, 'message': 'Validation errors', 'errors': validation_errors})
        
        # Sanitize input
        application_data = input_validator.sanitize_input(application_data)
        
        # Encrypt sensitive data
        encrypted_data = encryption.encrypt_data(application_data)
        
        # Initialize models if not done
        initialize_models()
        
        # AI/ML Analysis (33% of the system)
        ai_result = risk_model.predict_risk(application_data)
        
        # Soft Computing Analysis (33% of the system)
        fuzzy_result = hybrid_system.evaluate_loan_hybrid(application_data)
        
        # Security Analysis (33% of the system)
        security_status = auth_system.get_security_status(username)
        
        # Make final decision
        final_decision = make_final_decision(ai_result, fuzzy_result, security_status)
        
        # Generate report
        report = ReportGenerator.generate_approval_report(
            application_data, ai_result, fuzzy_result, final_decision
        )
        
        # Record processing
        processing_time = time.time() - start_time
        system_monitor.record_application(final_decision, processing_time)
        
        # Log application
        security_audit.log_loan_application(username, report['application_id'], 'processed')
        
        return jsonify({
            'success': True,
            'decision': final_decision,
            'report': report,
            'processing_time': processing_time
        })
        
    except Exception as e:
        security_audit.log_security_event('error', 'medium', f'Loan application error: {str(e)}')
        return jsonify({'success': False, 'message': f'Processing error: {str(e)}'})

def make_final_decision(ai_result, fuzzy_result, security_status):
    """Make final loan approval decision"""
    
    # Weight the different components
    ai_weight = 0.4
    fuzzy_weight = 0.4
    security_weight = 0.2
    
    # Calculate weighted score
    ai_score = ai_result.get('final_probability', 0.5)
    fuzzy_score = fuzzy_result.get('score', 50) / 100
    
    # Security penalty for locked accounts
    security_penalty = 0.1 if security_status.get('account_locked', False) else 0
    
    # Calculate final score
    final_score = (ai_weight * ai_score + 
                  fuzzy_weight * fuzzy_score - 
                  security_weight * security_penalty)
    
    # Make decision
    if final_score >= 0.7:
        return 'APPROVED'
    elif final_score >= 0.4:
        return 'CONDITIONAL'
    else:
        return 'REJECTED'

@app.route('/get_performance')
def get_performance():
    """Get system performance metrics"""
    if 'user_token' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'})
    
    performance = system_monitor.get_performance_summary()
    health = system_monitor.get_system_health()
    
    return jsonify({
        'success': True,
        'performance': performance,
        'health': health
    })

@app.route('/get_audit_trail')
def get_audit_trail():
    """Get audit trail"""
    if 'user_token' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'})
    
    username = session.get('username')
    audit_trail = security_audit.get_audit_trail(username)
    
    return jsonify({
        'success': True,
        'audit_trail': audit_trail
    })

@app.route('/change_password', methods=['POST'])
def change_password():
    """Change user password"""
    if 'user_token' not in session:
        return jsonify({'success': False, 'message': 'Authentication required'})
    
    username = session.get('username')
    data = request.get_json()
    old_password = data.get('old_password')
    new_password = data.get('new_password')
    
    success, message = auth_system.change_password(username, old_password, new_password)
    
    return jsonify({'success': success, 'message': message})

@app.route('/api/health')
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'models_initialized': models_initialized
    })

if __name__ == '__main__':
    # Initialize models on startup
    initialize_models()
    
    # Run the application
    app.run(
        host=app.config['HOST'],
        port=app.config['PORT'],
        debug=app.config['DEBUG']
    )
