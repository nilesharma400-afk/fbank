/*
          # [Operation Name]
          Final Fix for handle_new_user Function

          [This operation replaces the existing `handle_new_user` function with a more robust version that prevents registration errors.]

          ## Query Description: [This script updates the database function responsible for creating a user profile during registration. The previous version would fail if optional fields like 'Date of Birth' were empty, causing the entire registration to fail. This new version uses the `NULLIF` function to safely handle empty form fields, converting them to `NULL` in the database instead of causing an error. This ensures that the user registration process will complete successfully even if optional data is missing.]
          
          ## Metadata:
          - Schema-Category: "Structural"
          - Impact-Level: "Low"
          - Requires-Backup: false
          - Reversible: true
          
          ## Structure Details:
          - Function: `public.handle_new_user()`
          
          ## Security Implications:
          - RLS Status: Enabled
          - Policy Changes: No
          - Auth Requirements: This function is a `SECURITY DEFINER` trigger, which is a secure practice.
          
          ## Performance Impact:
          - Indexes: None
          - Triggers: Modifies the function called by an existing trigger.
          - Estimated Impact: Negligible. This is a very minor change to the function's logic.
          */

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, date_of_birth, gender, pan_number, aadhaar_number, phone, address, city, state, pincode)
  VALUES (
    NEW.id,
    NULLIF(NEW.raw_user_meta_data->>'full_name', ''),
    NULLIF(NEW.raw_user_meta_data->>'date_of_birth', '')::date,
    NULLIF(NEW.raw_user_meta_data->>'gender', ''),
    NULLIF(NEW.raw_user_meta_data->>'pan_number', ''),
    NULLIF(NEW.raw_user_meta_data->>'aadhaar_number', ''),
    NULLIF(NEW.raw_user_meta_data->>'phone', ''),
    NULLIF(NEW.raw_user_meta_data->>'address', ''),
    NULLIF(NEW.raw_user_meta_data->>'city', ''),
    NULLIF(NEW.raw_user_meta_data->>'state', ''),
    NULLIF(NEW.raw_user_meta_data->>'pincode', '')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
