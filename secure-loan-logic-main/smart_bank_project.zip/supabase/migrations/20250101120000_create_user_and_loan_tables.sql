/*
          # Create Profiles Table
          This table stores public user profile information, linked to the authentication system.

          ## Query Description: [This script creates a 'profiles' table to hold user data that complements Supabase's built-in 'auth.users' table. It is designed to store information collected during registration, such as personal and contact details. It establishes a one-to-one relationship with the 'auth.users' table, ensuring data integrity. No existing data will be affected as this is a new table.]
          
          ## Metadata:
          - Schema-Category: "Structural"
          - Impact-Level: "Low"
          - Requires-Backup: false
          - Reversible: true
          
          ## Structure Details:
          - Table: `profiles`
          - Columns: `id`, `full_name`, `date_of_birth`, `gender`, `pan_number`, `aadhaar_number`, `phone_number`, `address`, `city`, `state`, `pincode`, `created_at`
          - Constraints: `id` is a primary key and foreign key to `auth.users.id`. `pan_number` and `aadhaar_number` are unique.
          
          ## Security Implications:
          - RLS Status: Enabled
          - Policy Changes: Yes, new policies are created.
          - Auth Requirements: Users must be authenticated to interact with their own data.
          
          ## Performance Impact:
          - Indexes: A primary key index and two unique indexes are added.
          - Triggers: None.
          - Estimated Impact: Low performance impact, standard for a user profile table.
          */
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT,
    date_of_birth DATE,
    gender TEXT,
    pan_number TEXT UNIQUE,
    aadhaar_number TEXT UNIQUE,
    phone_number TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    pincode TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Policies for profiles table
CREATE POLICY "Allow individual read access" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Allow individual insert access" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Allow individual update access" ON public.profiles FOR UPDATE USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

/*
          # Create Loan Applications Table
          This table stores all loan applications submitted by users.

          ## Query Description: [This script creates a 'loan_applications' table to store the details and results of each loan application. It links each application to a user via the 'user_id' field. The use of JSONB columns for 'application_data' and 'result_data' provides flexibility for storing complex, structured data. No existing data will be affected.]
          
          ## Metadata:
          - Schema-Category: "Structural"
          - Impact-Level: "Low"
          - Requires-Backup: false
          - Reversible: true
          
          ## Structure Details:
          - Table: `loan_applications`
          - Columns: `id`, `user_id`, `created_at`, `application_data`, `status`, `result_data`
          - Constraints: `id` is a primary key, `user_id` is a foreign key to `auth.users.id`.
          
          ## Security Implications:
          - RLS Status: Enabled
          - Policy Changes: Yes, new policies are created.
          - Auth Requirements: Users can only access their own loan applications.
          
          ## Performance Impact:
          - Indexes: A primary key index and a foreign key index are added.
          - Triggers: None.
          - Estimated Impact: Low. Performance will depend on the size of the JSONB data and query patterns.
          */
CREATE TABLE public.loan_applications (
    id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    application_data JSONB,
    status TEXT,
    result_data JSONB
);

-- Enable Row Level Security
ALTER TABLE public.loan_applications ENABLE ROW LEVEL SECURITY;

-- Policies for loan_applications table
CREATE POLICY "Allow individual read access" ON public.loan_applications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Allow individual insert access" ON public.loan_applications FOR INSERT WITH CHECK (auth.uid() = user_id);
</sql>
