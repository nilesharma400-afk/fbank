/*
          # Initial Schema Setup
          This script sets up the initial database schema for the Smart Loan Advisor application.
          It creates two main tables: `profiles` to store user information and `loan_applications` to store loan submission data.
          It also configures Row Level Security (RLS) to ensure users can only access their own data.

          ## Query Description: This is a structural and security setup. It creates new tables and enables security policies. No existing data will be affected as these tables are new. It is safe to run on a new project.

          ## Metadata:
          - Schema-Category: "Structural"
          - Impact-Level: "Low"
          - Requires-Backup: false
          - Reversible: true (by dropping the tables and policies)

          ## Structure Details:
          - Tables Created: `public.profiles`, `public.loan_applications`
          - Triggers Created: `on_auth_user_created` on `auth.users`
          - Functions Created: `public.handle_new_user()`

          ## Security Implications:
          - RLS Status: Enabled on `profiles` and `loan_applications`.
          - Policy Changes: Yes, new policies are created to restrict data access to the record owner.
          - Auth Requirements: Policies are based on `auth.uid()`, linking data to authenticated users.

          ## Performance Impact:
          - Indexes: Primary keys and foreign keys are indexed by default.
          - Triggers: A trigger is added to `auth.users` to automate profile creation. This has a negligible impact on user sign-up performance.
          - Estimated Impact: Low.
          */

-- 1. Create Profiles Table
-- This table stores public user information, linked to the authentication system.
CREATE TABLE public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT,
    date_of_birth DATE,
    gender TEXT,
    pan_number TEXT,
    aadhaar_number TEXT,
    phone TEXT,
    address TEXT,
    city TEXT,
    state TEXT,
    pincode TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON TABLE public.profiles IS 'Stores public profile information for each user.';

-- 2. Create Loan Applications Table
-- This table stores all loan application data submitted by users.
CREATE TABLE public.loan_applications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    age INT,
    employment_type TEXT,
    employment_years INT,
    monthly_income NUMERIC,
    monthly_debt NUMERIC,
    cibil_score INT,
    loan_amount NUMERIC,
    property_value NUMERIC,
    education TEXT,
    marital_status TEXT,
    property_type TEXT,
    status TEXT DEFAULT 'pending',
    decision TEXT,
    report JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON TABLE public.loan_applications IS 'Stores loan application details for users.';

-- 3. Enable Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.loan_applications ENABLE ROW LEVEL SECURITY;

-- 4. Create RLS Policies for Profiles
CREATE POLICY "Users can view their own profile."
ON public.profiles FOR SELECT
USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile."
ON public.profiles FOR INSERT
WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile."
ON public.profiles FOR UPDATE
USING (auth.uid() = id);

-- 5. Create RLS Policies for Loan Applications
CREATE POLICY "Users can view their own loan applications."
ON public.loan_applications FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create loan applications for themselves."
ON public.loan_applications FOR INSERT
WITH CHECK (auth.uid() = user_id);

-- 6. Create a function to automatically create a profile on new user sign-up
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, email)
  VALUES (new.id, new.raw_user_meta_data->>'full_name', new.email);
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 7. Create a trigger to call the function when a new user is created in auth.users
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.handle_new_user();
