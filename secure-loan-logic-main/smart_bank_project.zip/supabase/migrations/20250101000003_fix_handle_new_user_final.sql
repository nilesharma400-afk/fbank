/*
# [Operation Name]
Update `handle_new_user` Function for Robustness

[Description of what this operation does]
This script replaces the existing `handle_new_user` function with a more resilient version. The previous function would fail if optional form fields (like 'date_of_birth') were submitted as empty strings, causing the entire user registration to fail. This new version uses the `NULLIF` function to gracefully convert any empty strings into `NULL` values before inserting them into the `profiles` table. This prevents type-casting errors and ensures that user registration can complete successfully even with incomplete profile data.

## Query Description: [This operation will update a database function to prevent registration errors. It fixes a critical bug where registrations would fail if optional fields were left blank. This change is safe and does not affect any existing user data, but it is essential for allowing new users to sign up correctly.]

## Metadata:
- Schema-Category: ["Structural"]
- Impact-Level: ["Low"]
- Requires-Backup: [false]
- Reversible: [true]

## Structure Details:
- Function `public.handle_new_user()`: The logic is being updated to be more robust.

## Security Implications:
- RLS Status: [Enabled]
- Policy Changes: [No]
- Auth Requirements: [None]

## Performance Impact:
- Indexes: [None]
- Triggers: [The `on_auth_user_created` trigger will now execute more reliably.]
- Estimated Impact: [Negligible performance impact. Improves system reliability.]
*/

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (
      id,
      full_name,
      date_of_birth,
      gender,
      pan_number,
      aadhaar_number,
      phone,
      address,
      city,
      state,
      pincode
  )
  values (
      new.id,
      NULLIF(new.raw_user_meta_data ->> 'full_name', ''),
      NULLIF(new.raw_user_meta_data ->> 'date_of_birth', '')::date,
      NULLIF(new.raw_user_meta_data ->> 'gender', ''),
      NULLIF(new.raw_user_meta_data ->> 'pan_number', ''),
      NULLIF(new.raw_user_meta_data ->> 'aadhaar_number', ''),
      NULLIF(new.raw_user_meta_data ->> 'phone', ''),
      NULLIF(new.raw_user_meta_data ->> 'address', ''),
      NULLIF(new.raw_user_meta_data ->> 'city', ''),
      NULLIF(new.raw_user_meta_data ->> 'state', ''),
      NULLIF(new.raw_user_meta_data ->> 'pincode', '')
  );
  return new;
end;
$$;
