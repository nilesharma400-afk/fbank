/*
# [Fix] Update User Profile Creation Function
This migration updates the `create_user_profile` function to be more robust. It now correctly handles cases where optional form fields might be submitted as empty strings, preventing errors during user registration.

## Query Description: [This operation modifies a database function to improve its error handling. It ensures that empty text values for dates are treated as NULL, preventing casting errors. This change is safe and does not affect existing data.]

## Metadata:
- Schema-Category: ["Structural"]
- Impact-Level: ["Low"]
- Requires-Backup: [false]
- Reversible: [true]

## Structure Details:
- Function `public.create_user_profile()` is being replaced with an updated version.

## Security Implications:
- RLS Status: [No Change]
- Policy Changes: [No]
- Auth Requirements: [No Change]

## Performance Impact:
- Indexes: [No Change]
- Triggers: [No Change]
- Estimated Impact: [None]
*/

create or replace function public.create_user_profile()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, date_of_birth, gender, pan_number, aadhaar_number, phone, address, city, state, pincode)
  values (
    new.id,
    new.raw_user_meta_data->>'full_name',
    (NULLIF(new.raw_user_meta_data->>'date_of_birth', ''))::date,
    new.raw_user_meta_data->>'gender',
    new.raw_user_meta_data->>'pan_number',
    new.raw_user_meta_data->>'aadhaar_number',
    new.raw_user_meta_data->>'phone',
    new.raw_user_meta_data->>'address',
    new.raw_user_meta_data->>'city',
    new.raw_user_meta_data->>'state',
    new.raw_user_meta_data->>'pincode'
  );
  return new;
end;
$$;
