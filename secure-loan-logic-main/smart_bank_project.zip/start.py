#!/usr/bin/env python3
"""
Smart Loan Approval Advisor - Startup Script
"""

import os
import sys
import subprocess

def check_requirements():
    """Check if all required packages are installed"""
    required_packages = [
        'flask', 'numpy', 'pandas', 'scikit-learn', 'tensorflow',
        'matplotlib', 'seaborn', 'cryptography', 'skfuzzy', 'deap'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing_packages.append(package)
    
    if missing_packages:
        print(f"Missing packages: {', '.join(missing_packages)}")
        print("Installing missing packages...")
        subprocess.check_call([sys.executable, '-m', 'pip', 'install'] + missing_packages)
    
    print("All required packages are installed!")

def create_directories():
    """Create necessary directories"""
    directories = [
        'data/trained_models',
        'logs',
        'uploads'
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
    
    print("Directories created successfully!")

def initialize_models():
    """Initialize and train models"""
    try:
        from models.loan_model import generate_sample_data
        from models.neural_network import RiskAssessmentModel
        from soft_computing.fuzzy_system import FuzzyLoanSystem
        from soft_computing.genetic_algorithm import HybridSoftComputingSystem
        
        print("Initializing AI/ML models...")
        
        # Generate sample data
        sample_data = generate_sample_data()
        print(f"Generated {len(sample_data)} sample records")
        
        # Initialize models
        risk_model = RiskAssessmentModel()
        fuzzy_system = FuzzyLoanSystem()
        hybrid_system = HybridSoftComputingSystem()
        
        print("Models initialized successfully!")
        return True
        
    except Exception as e:
        print(f"Error initializing models: {str(e)}")
        return False

def main():
    """Main startup function"""
    print("=" * 50)
    print("Smart Loan Approval Advisor - Startup")
    print("=" * 50)
    
    # Check requirements
    check_requirements()
    
    # Create directories
    create_directories()
    
    # Initialize models
    if initialize_models():
        print("\n" + "=" * 50)
        print("System ready! Starting application...")
        print("=" * 50)
        
        # Start the Flask application
        os.system("python app.py")
    else:
        print("Failed to initialize models. Please check the error messages above.")
        sys.exit(1)

if __name__ == "__main__":
    main()
