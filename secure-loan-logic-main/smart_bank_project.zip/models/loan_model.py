import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
import os

class LoanApprovalModel:
    """
    AI/ML Model for Loan Approval Decision Making
    Implements Decision Trees and Random Forest algorithms
    """
    
    def __init__(self):
        self.decision_tree = DecisionTreeClassifier(random_state=42)
        self.random_forest = RandomForestClassifier(n_estimators=100, random_state=42)
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.is_trained = False
        
    def prepare_data(self, data):
        """
        Prepare and preprocess the loan application data
        """
        # Create a copy to avoid modifying original data
        df = data.copy()
        
        # Handle categorical variables
        categorical_columns = ['employment_type', 'education', 'marital_status', 'property_type']
        
        for col in categorical_columns:
            if col in df.columns:
                if col not in self.label_encoders:
                    self.label_encoders[col] = LabelEncoder()
                    df[col] = self.label_encoders[col].fit_transform(df[col].astype(str))
                else:
                    df[col] = self.label_encoders[col].transform(df[col].astype(str))
        
        # Feature engineering
        df['debt_to_income_ratio'] = df['monthly_debt'] / (df['monthly_income'] + 1e-6)
        df['loan_to_value_ratio'] = df['loan_amount'] / (df['property_value'] + 1e-6)
        df['cibil_score_normalized'] = df['cibil_score'] / 900.0
        df['age_group'] = pd.cut(df['age'], bins=[0, 25, 35, 50, 100], labels=[0, 1, 2, 3])
        
        # Select features for training
        feature_columns = [
            'age', 'monthly_income', 'monthly_debt', 'cibil_score',
            'loan_amount', 'property_value', 'employment_years',
            'debt_to_income_ratio', 'loan_to_value_ratio', 'cibil_score_normalized'
        ]
        
        # Add categorical features
        for col in categorical_columns:
            if col in df.columns:
                feature_columns.append(col)
        
        return df[feature_columns]
    
    def train_model(self, X_train, y_train):
        """
        Train both Decision Tree and Random Forest models
        """
        # Scale the features
        X_train_scaled = self.scaler.fit_transform(X_train)
        
        # Train Decision Tree
        self.decision_tree.fit(X_train_scaled, y_train)
        
        # Train Random Forest
        self.random_forest.fit(X_train_scaled, y_train)
        
        self.is_trained = True
        
    def predict(self, X):
        """
        Make predictions using ensemble of both models
        """
        if not self.is_trained:
            raise ValueError("Model must be trained before making predictions")
        
        X_scaled = self.scaler.transform(X)
        
        # Get predictions from both models
        dt_pred = self.decision_tree.predict(X_scaled)
        rf_pred = self.random_forest.predict(X_scaled)
        
        # Get prediction probabilities
        dt_proba = self.decision_tree.predict_proba(X_scaled)
        rf_proba = self.random_forest.predict_proba(X_scaled)
        
        # Ensemble prediction (weighted average)
        ensemble_proba = 0.4 * dt_proba + 0.6 * rf_proba
        ensemble_pred = np.argmax(ensemble_proba, axis=1)
        
        return {
            'prediction': ensemble_pred[0],
            'probability': ensemble_proba[0],
            'decision_tree_pred': dt_pred[0],
            'random_forest_pred': rf_pred[0],
            'decision_tree_proba': dt_proba[0],
            'random_forest_proba': rf_proba[0]
        }
    
    def get_feature_importance(self):
        """
        Get feature importance from Random Forest
        """
        if not self.is_trained:
            return None
        
        return self.random_forest.feature_importances_
    
    def save_model(self, filepath):
        """
        Save the trained model
        """
        model_data = {
            'decision_tree': self.decision_tree,
            'random_forest': self.random_forest,
            'scaler': self.scaler,
            'label_encoders': self.label_encoders,
            'is_trained': self.is_trained
        }
        joblib.dump(model_data, filepath)
    
    def load_model(self, filepath):
        """
        Load a pre-trained model
        """
        if os.path.exists(filepath):
            model_data = joblib.load(filepath)
            self.decision_tree = model_data['decision_tree']
            self.random_forest = model_data['random_forest']
            self.scaler = model_data['scaler']
            self.label_encoders = model_data['label_encoders']
            self.is_trained = model_data['is_trained']
        else:
            raise FileNotFoundError(f"Model file not found: {filepath}")

def generate_sample_data():
    """
    Generate sample loan application data for training
    """
    np.random.seed(42)
    n_samples = 1000
    
    data = {
        'age': np.random.randint(22, 65, n_samples),
        'monthly_income': np.random.randint(20000, 150000, n_samples),
        'monthly_debt': np.random.randint(5000, 50000, n_samples),
        'cibil_score': np.random.randint(300, 900, n_samples),
        'loan_amount': np.random.randint(100000, 2000000, n_samples),
        'property_value': np.random.randint(200000, 5000000, n_samples),
        'employment_years': np.random.randint(1, 30, n_samples),
        'employment_type': np.random.choice(['salaried', 'self_employed', 'business'], n_samples),
        'education': np.random.choice(['graduate', 'post_graduate', 'diploma', 'high_school'], n_samples),
        'marital_status': np.random.choice(['single', 'married', 'divorced'], n_samples),
        'property_type': np.random.choice(['residential', 'commercial', 'agricultural'], n_samples)
    }
    
    df = pd.DataFrame(data)
    
    # Create target variable based on business rules
    df['loan_approved'] = (
        (df['cibil_score'] >= 650) &
        (df['monthly_income'] >= 30000) &
        (df['monthly_debt'] / df['monthly_income'] <= 0.4) &
        (df['employment_years'] >= 2) &
        (df['age'] >= 25) &
        (df['age'] <= 60)
    ).astype(int)
    
    return df

def load_large_dataset():
    """
    Load the large dataset for training
    """
    try:
        df = pd.read_csv('data/large_loan_dataset_cibil.csv')
        print(f"Loaded large dataset with {len(df)} records")
        print(f"Approval rate: {df['loan_approved'].mean():.2%}")
        return df
    except FileNotFoundError:
        print("Large dataset not found, generating sample data...")
        return generate_sample_data()
