import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import joblib
import os

class NeuralNetworkModel:
    """
    Neural Network Model for Advanced Risk Assessment
    Implements Multi-Layer Perceptron (MLP) using TensorFlow/Keras
    """
    
    def __init__(self, input_dim=10):
        self.input_dim = input_dim
        self.model = None
        self.scaler = None
        self.is_trained = False
        
    def build_model(self):
        """
        Build the neural network architecture
        """
        self.model = keras.Sequential([
            layers.Dense(64, activation='relu', input_shape=(self.input_dim,)),
            layers.Dropout(0.3),
            layers.Dense(32, activation='relu'),
            layers.Dropout(0.2),
            layers.Dense(16, activation='relu'),
            layers.Dense(1, activation='sigmoid')
        ])
        
        # Compile the model
        self.model.compile(
            optimizer='adam',
            loss='binary_crossentropy',
            metrics=['accuracy', 'precision', 'recall']
        )
        
    def train_model(self, X_train, y_train, X_val=None, y_val=None, epochs=100):
        """
        Train the neural network model
        """
        if self.model is None:
            self.build_model()
        
        # Prepare validation data
        validation_data = None
        if X_val is not None and y_val is not None:
            validation_data = (X_val, y_val)
        
        # Train the model
        history = self.model.fit(
            X_train, y_train,
            epochs=epochs,
            batch_size=32,
            validation_data=validation_data,
            verbose=0
        )
        
        self.is_trained = True
        return history
    
    def predict(self, X):
        """
        Make predictions using the neural network
        """
        if not self.is_trained or self.model is None:
            raise ValueError("Model must be trained before making predictions")
        
        predictions = self.model.predict(X, verbose=0)
        probabilities = predictions.flatten()
        
        # Convert probabilities to binary predictions
        binary_predictions = (probabilities > 0.5).astype(int)
        
        return {
            'prediction': binary_predictions[0],
            'probability': probabilities[0],
            'confidence': max(probabilities[0], 1 - probabilities[0])
        }
    
    def predict_proba(self, X):
        """
        Get prediction probabilities
        """
        if not self.is_trained or self.model is None:
            raise ValueError("Model must be trained before making predictions")
        
        return self.model.predict(X, verbose=0)
    
    def evaluate_model(self, X_test, y_test):
        """
        Evaluate the model performance
        """
        if not self.is_trained or self.model is None:
            raise ValueError("Model must be trained before evaluation")
        
        loss, accuracy, precision, recall = self.model.evaluate(X_test, y_test, verbose=0)
        
        return {
            'loss': loss,
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1_score': 2 * (precision * recall) / (precision + recall + 1e-8)
        }
    
    def save_model(self, filepath):
        """
        Save the trained model
        """
        if self.model is not None:
            self.model.save(filepath)
        
        # Save scaler separately
        scaler_path = filepath.replace('.h5', '_scaler.pkl')
        if self.scaler is not None:
            joblib.dump(self.scaler, scaler_path)
    
    def load_model(self, filepath):
        """
        Load a pre-trained model
        """
        if os.path.exists(filepath):
            self.model = keras.models.load_model(filepath)
            self.is_trained = True
            
            # Load scaler if exists
            scaler_path = filepath.replace('.h5', '_scaler.pkl')
            if os.path.exists(scaler_path):
                self.scaler = joblib.load(scaler_path)
        else:
            raise FileNotFoundError(f"Model file not found: {filepath}")

class RiskAssessmentModel:
    """
    Combined AI/ML Model for comprehensive risk assessment
    """
    
    def __init__(self):
        self.loan_model = None
        self.neural_network = None
        self.is_initialized = False
        
    def initialize_models(self):
        """
        Initialize both models
        """
        from models.loan_model import LoanApprovalModel
        self.loan_model = LoanApprovalModel()
        self.neural_network = NeuralNetworkModel()
        self.is_initialized = True
    
    def train_models(self, data):
        """
        Train both models on the provided data
        """
        if not self.is_initialized:
            self.initialize_models()
        
        # Prepare data
        X = self.loan_model.prepare_data(data.drop('loan_approved', axis=1))
        y = data['loan_approved']
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        X_train_nn, X_val, y_train_nn, y_val = train_test_split(X_train, y_train, test_size=0.2, random_state=42)
        
        # Train traditional ML model
        self.loan_model.train_model(X_train, y_train)
        
        # Scale data for neural network
        from sklearn.preprocessing import StandardScaler
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train_nn)
        X_val_scaled = scaler.transform(X_val)
        X_test_scaled = scaler.transform(X_test)
        
        self.neural_network.scaler = scaler
        
        # Train neural network
        self.neural_network.train_model(X_train_scaled, y_train_nn, X_val_scaled, y_val)
        
        return X_test_scaled, y_test
    
    def predict_risk(self, application_data):
        """
        Get comprehensive risk assessment using both models
        """
        if not self.is_initialized:
            raise ValueError("Models must be initialized first")
        
        # Prepare data
        X = self.loan_model.prepare_data(application_data)
        X_scaled = self.neural_network.scaler.transform(X)
        
        # Get predictions from both models
        ml_prediction = self.loan_model.predict(X)
        nn_prediction = self.neural_network.predict(X_scaled)
        
        # Combine predictions
        combined_probability = 0.6 * ml_prediction['probability'][1] + 0.4 * nn_prediction['probability']
        combined_prediction = 1 if combined_probability > 0.5 else 0
        
        return {
            'final_prediction': combined_prediction,
            'final_probability': combined_probability,
            'ml_prediction': ml_prediction,
            'neural_network_prediction': nn_prediction,
            'risk_level': self._calculate_risk_level(combined_probability)
        }
    
    def _calculate_risk_level(self, probability):
        """
        Calculate risk level based on probability
        """
        if probability < 0.3:
            return "Low Risk"
        elif probability < 0.7:
            return "Medium Risk"
        else:
            return "High Risk"
    
    def save_models(self, base_path):
        """
        Save both models
        """
        self.loan_model.save_model(f"{base_path}/loan_model.pkl")
        self.neural_network.save_model(f"{base_path}/neural_network.h5")
    
    def load_models(self, base_path):
        """
        Load both models
        """
        self.loan_model = LoanApprovalModel()
        self.neural_network = NeuralNetworkModel()
        
        self.loan_model.load_model(f"{base_path}/loan_model.pkl")
        self.neural_network.load_model(f"{base_path}/neural_network.h5")
        
        self.is_initialized = True
