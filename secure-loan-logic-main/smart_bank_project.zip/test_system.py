#!/usr/bin/env python3
"""
Test script for Smart Loan Approval Advisor
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def test_imports():
    """Test if all modules can be imported"""
    print("Testing imports...")
    
    try:
        from models.loan_model import LoanApprovalModel, generate_sample_data, load_large_dataset
        print("✓ AI/ML models imported successfully")
    except Exception as e:
        print(f"✗ Error importing AI/ML models: {e}")
        return False
    
    try:
        from soft_computing.fuzzy_system import FuzzyLoanSystem
        from soft_computing.genetic_algorithm import HybridSoftComputingSystem
        print("✓ Soft computing modules imported successfully")
    except Exception as e:
        print(f"✗ Error importing soft computing modules: {e}")
        return False
    
    try:
        from security.encryption import DataEncryption, InputValidation
        from security.authentication import AuthenticationSystem
        print("✓ Security modules imported successfully")
    except Exception as e:
        print(f"✗ Error importing security modules: {e}")
        return False
    
    try:
        from utils.helpers import DataProcessor, ReportGenerator
        print("✓ Utility modules imported successfully")
    except Exception as e:
        print(f"✗ Error importing utility modules: {e}")
        return False
    
    return True

def test_ai_ml_functionality():
    """Test AI/ML functionality"""
    print("\nTesting AI/ML functionality...")
    
    try:
        from models.loan_model import LoanApprovalModel, generate_sample_data, load_large_dataset
        
        # Generate sample data
        sample_data = generate_sample_data()
        print(f"✓ Generated {len(sample_data)} sample records")
        
        # Test model
        model = LoanApprovalModel()
        X = model.prepare_data(sample_data.drop('loan_approved', axis=1))
        y = sample_data['loan_approved']
        
        # Train model
        model.train_model(X, y)
        print("✓ Model trained successfully")
        
        # Test prediction
        test_data = sample_data.iloc[0:1].drop('loan_approved', axis=1)
        prediction = model.predict(model.prepare_data(test_data))
        print(f"✓ Prediction made: {prediction['prediction']}")
        
        return True
        
    except Exception as e:
        print(f"✗ AI/ML test failed: {e}")
        return False

def test_fuzzy_system():
    """Test fuzzy system functionality"""
    print("\nTesting Fuzzy System functionality...")
    
    try:
        from soft_computing.fuzzy_system import FuzzyLoanSystem
        
        fuzzy_system = FuzzyLoanSystem()
        fuzzy_system.build_fuzzy_system()
        print("✓ Fuzzy system built successfully")
        
        # Test evaluation
        result = fuzzy_system.evaluate_loan(
            cibil_score=700,
            monthly_income=50000,
            monthly_debt=15000,
            employment_years=5,
            loan_amount=800000,
            max_loan_amount=2000000
        )
        print(f"✓ Fuzzy evaluation completed: {result['decision']}")
        
        return True
        
    except Exception as e:
        print(f"✗ Fuzzy system test failed: {e}")
        return False

def test_security():
    """Test security functionality"""
    print("\nTesting Security functionality...")
    
    try:
        from security.encryption import DataEncryption, InputValidation
        from security.authentication import AuthenticationSystem
        
        # Test encryption
        encryption = DataEncryption()
        test_data = {"name": "Test User", "income": 50000}
        encrypted = encryption.encrypt_data(test_data)
        decrypted = encryption.decrypt_data(encrypted)
        print("✓ Encryption/Decryption working")
        
        # Test authentication
        auth = AuthenticationSystem()
        success, message = auth.register_user("testuser", "TestPass123!", "customer")
        print(f"✓ User registration: {success}")
        
        # Test validation
        validator = InputValidation()
        test_application = {
            "name": "Test User",
            "age": 30,
            "monthly_income": 50000,
            "monthly_debt": 15000,
            "credit_score": 700,
            "loan_amount": 800000,
            "employment_years": 5
        }
        errors = validator.validate_loan_application(test_application)
        print(f"✓ Input validation: {len(errors)} errors found")
        
        return True
        
    except Exception as e:
        print(f"✗ Security test failed: {e}")
        return False

def test_integration():
    """Test integrated system"""
    print("\nTesting Integrated System...")
    
    try:
        from models.loan_model import LoanApprovalModel, generate_sample_data, load_large_dataset
        from soft_computing.fuzzy_system import FuzzyLoanSystem
        from security.encryption import DataEncryption
        from utils.helpers import DataProcessor
        
        # Generate test data
        sample_data = generate_sample_data()
        test_application = sample_data.iloc[0].to_dict()
        
        # Test data processing
        processor = DataProcessor()
        errors = processor.validate_loan_data(test_application)
        print(f"✓ Data validation: {len(errors)} errors")
        
        # Test encryption
        encryption = DataEncryption()
        encrypted_data = encryption.encrypt_data(test_application)
        print("✓ Data encryption working")
        
        # Test AI/ML
        model = LoanApprovalModel()
        X = model.prepare_data(sample_data.drop('loan_approved', axis=1))
        y = sample_data['loan_approved']
        model.train_model(X, y)
        
        test_data = sample_data.iloc[0:1].drop('loan_approved', axis=1)
        prediction = model.predict(model.prepare_data(test_data))
        print(f"✓ AI/ML prediction: {prediction['prediction']}")
        
        # Test fuzzy system
        fuzzy_system = FuzzyLoanSystem()
        fuzzy_system.build_fuzzy_system()
        fuzzy_result = fuzzy_system.evaluate_loan(
            test_application['cibil_score'],
            test_application['monthly_income'],
            test_application['monthly_debt'],
            test_application['employment_years'],
            test_application['loan_amount'],
            2000000
        )
        print(f"✓ Fuzzy system result: {fuzzy_result['decision']}")
        
        return True
        
    except Exception as e:
        print(f"✗ Integration test failed: {e}")
        return False

def main():
    """Main test function"""
    print("=" * 60)
    print("Smart Loan Approval Advisor - System Test")
    print("=" * 60)
    
    tests = [
        ("Import Test", test_imports),
        ("AI/ML Test", test_ai_ml_functionality),
        ("Fuzzy System Test", test_fuzzy_system),
        ("Security Test", test_security),
        ("Integration Test", test_integration)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n{test_name}:")
        print("-" * 40)
        if test_func():
            passed += 1
            print(f"✓ {test_name} PASSED")
        else:
            print(f"✗ {test_name} FAILED")
    
    print("\n" + "=" * 60)
    print(f"Test Results: {passed}/{total} tests passed")
    print("=" * 60)
    
    if passed == total:
        print("🎉 All tests passed! System is ready to use.")
        return True
    else:
        print("❌ Some tests failed. Please check the errors above.")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
